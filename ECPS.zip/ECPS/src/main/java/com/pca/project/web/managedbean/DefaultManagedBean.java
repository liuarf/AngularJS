package com.pca.project.web.managedbean;

import java.io.Serializable;

/**
 * 為控制JSF預設行為的ManagedBean
 * 
 * @author marvin.wc.hsu
 *
 */
public class DefaultManagedBean implements Serializable {

	private static final long serialVersionUID = -2642873677302387287L;
	/**
	 * DataTable分頁有多少筆數
	 */
	private int rowsOfPerPage;

	public int getRowsOfPerPage() {
		return rowsOfPerPage;
	}

	public void setRowsOfPerPage(int rowsOfPerPage) {
		this.rowsOfPerPage = rowsOfPerPage;
	}

}
