package com.pca.project.web.vowrapper;

import com.pca.corefrmwk.web.vowrapper.impl.VoWrapperImpl;
import com.pca.project.bo.Detail;
import com.pca.project.web.vo.DetailVo;

/**
 * 轉換Detail為DetailVo的Wrapper
 * 
 */
public class DetailVoWrapper extends VoWrapperImpl<Detail, java.lang.String> {

	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	@Override
	public DetailVo wrap(Detail bo) {
		return new DetailVo(bo);
	}
}