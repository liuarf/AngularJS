package com.pca.project.bo;

import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.pca.corefrmwk.persistence.jpa.entity.BaseBoImpl;

/**
 * The persistent class for the MANY1 database table.
 * 
 */
@Entity
@Table(name = "MANY1")
@NamedQuery(name = "Many1.findAll", query = "SELECT m FROM Many1 m")
public class Many1 extends BaseBoImpl<String> {
	private static final long serialVersionUID = 1L;
	private String id;
	private String code;
	private String name;
	private Set<Many2> many2s;

	public Many1() {
	}

	@Id
	@GeneratedValue(generator = "many1-uuid")
	@GenericGenerator(name = "many1-uuid", strategy = "uuid2")
	@Basic(optional = false)
	@Column(name = "ID")
	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	@Basic(optional = false)
	@Column(name = "CODE")
	public String getCode() {
		return this.code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	@Basic(optional = false)
	@Column(name = "NAME")
	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@ManyToMany(fetch = FetchType.EAGER, targetEntity = Many2.class, cascade = { CascadeType.MERGE })
	@JoinTable(name = "CROSS_TABLE", joinColumns = { @JoinColumn(name = "MANY1_ID", referencedColumnName = "ID", nullable = false) }, inverseJoinColumns = { @JoinColumn(name = "MANY2_ID", referencedColumnName = "ID", nullable = false) })
	public Set<Many2> getMany2s() {
		return this.many2s;
	}

	public void setMany2s(Set<Many2> many2s) {
		this.many2s = many2s;
	}

	public void addMany2(Many2 many2) {
		if (this.getMany2s() == null) {
			this.setMany2s(new LinkedHashSet<Many2>());
		}

		this.getMany2s().add(many2);

		if (many2.getMany1s() != null) {
			many2.getMany1s().add(this);
		}
	}

	public void removeMany2(Many2 many2) {
		if (this.getMany2s() == null) {
			this.setMany2s(new LinkedHashSet<Many2>());
		}

		this.getMany2s().remove(many2);

		if (many2.getMany1s() != null) {
			many2.getMany1s().remove(this);
		}
	}

	public void clearMany2s() {
		if (this.getMany2s() != null) {
			this.getMany2s().clear();
		}
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((code == null) ? 0 : code.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Many1 other = (Many1) obj;
		if (code == null) {
			if (other.code != null)
				return false;
		} else if (!code.equals(other.code))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}

}