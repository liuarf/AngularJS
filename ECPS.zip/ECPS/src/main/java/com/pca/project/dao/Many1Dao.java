package com.pca.project.dao;

import java.util.List;

import com.pca.corefrmwk.persistence.dao.BaseDao;
import com.pca.project.bo.Many1;

public interface Many1Dao extends BaseDao<Many1, java.lang.String> {

	/**
	 * 假如Entity(Business Object)，有Many-to-One或Many-to-Many的狀況， 則Code
	 * Generator會產生此Interface以供修改使用，可自行改成需要的Method，
	 * 主要作用是在read頁面就Fetch所有相關關聯的資料，免得再update頁面出現問題
	 * 
	 * @return List<Many1>
	 */
	List<Many1> findAllFetchRelation();

}
