package com.pca.project.web.util;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;

import javax.faces.model.SelectItem;

import org.apache.commons.beanutils.MethodUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.pca.corefrmwk.service.BaseService;

/**
 * 用於下拉式選單，下面的code為參考用法， 但目前不建議使用，因為與session中的map綁訂 Current狀態下，可能會無法取到最新的值
 *
 *
 */
public class SelectHelper implements Serializable {

	private static final long serialVersionUID = -8609880167162019398L;

	private static final Log LOG = LogFactory.getLog(SelectHelper.class);
	// 服務名稱
	private String serviceName;
	// 回傳的下拉式選單內容list
	private List<SelectItem> selectList;
	// 取得value的方法名稱
	private String valueGetterName;
	// 取得label的方法名稱
	private String labelGetterName;

	private SelectHelper masterSelectHelper;

	private String detailReaderName;
	// 服務中的讀取方法
	private String readMethodName;
	// 服務中讀取方法的參數
	private Object[] readMethodParms;
	// 如果 showableValueSet 不等於 null
	// 就只要 show 出 showableValueSet 內有指定的 Id 的 item 即可
	private Set<?> showableValueSet = null;
	// 下拉式選單的第一個selectItem
	public final static SelectItem EMPTY_SELECTITEM = new SelectItem("",
			"-----");

	public SelectHelper() {

	}

	/**
	 * 依參數建立SelectHelper
	 * 
	 * @param serviceName
	 *            服務名稱
	 * @param valueGetterName
	 *            value方法名稱
	 * @param labelGetterName
	 *            label方法名稱
	 */
	public SelectHelper(final String serviceName, final String valueGetterName,
			final String labelGetterName) {
		this.serviceName = serviceName;
		this.valueGetterName = valueGetterName;
		this.labelGetterName = labelGetterName;
	}

	/**
	 * 依參數建立SelectHelper
	 * 
	 * @param serviceName
	 *            服務名稱
	 * @param valueGetterName
	 *            value方法名稱
	 * @param labelGetterName
	 *            label方法名稱
	 * @param readMethodName
	 *            服務中的讀取方法名稱
	 */
	public SelectHelper(final String serviceName, final String valueGetterName,
			final String labelGetterName, final String readMethodName) {
		this.serviceName = serviceName;
		this.valueGetterName = valueGetterName;
		this.labelGetterName = labelGetterName;
		this.readMethodName = readMethodName;
	}

	/**
	 * 依參數建立SelectHelper
	 * 
	 * @param serviceName
	 *            服務名稱
	 * @param valueGetterName
	 *            value方法名稱
	 * @param labelGetterName
	 *            label方法名稱
	 * @param readMethodName
	 *            服務中的讀取方法名稱
	 * @param readMethodParms
	 *            服務中的讀取方法的參數
	 */
	public SelectHelper(final String serviceName, final String valueGetterName,
			final String labelGetterName, final String readMethodName,
			final Object[] readMethodParms) {
		this.serviceName = serviceName;
		this.valueGetterName = valueGetterName;
		this.labelGetterName = labelGetterName;
		this.readMethodName = readMethodName;
		this.readMethodParms = readMethodParms;
	}

	/**
	 * 依bo名稱建立SelectHelper 服務名稱會預設為bo名稱+Service value方法名稱會預設為getId
	 * label方法名稱會預設為getName
	 * 
	 * @param boName
	 *            bo名稱
	 */
	public SelectHelper(final String boName) {
		this(boName + "Service", "getId", "getName");
	}

	/**
	 * 依bo名稱、map前置詞建立SelectHelper
	 * 
	 * @param boName
	 *            bo名稱
	 * @param mapPrifx
	 *            map前置詞
	 */
	public SelectHelper(final String boName, final String mapPrifx) {
		this(boName + "Service", mapPrifx + boName + "Map", "getId", "getName");
	}

	public SelectHelper(final String boName, final Set<?> showableValueSet) {
		this(boName);
		this.showableValueSet = showableValueSet;
	}

	public SelectHelper(final String serviceName, final String mapName,
			final String valueGetterName, final String labelGetterName,
			final SelectHelper masterSelectHelper, final String detailReaderName) {
		this(serviceName, mapName, valueGetterName, labelGetterName);
		this.masterSelectHelper = masterSelectHelper;
		this.detailReaderName = detailReaderName;
	}

	public SelectHelper(final SelectHelper masterSelectHelper) {
		this.masterSelectHelper = masterSelectHelper;

	}

	/**
	 * 取得SelectItem List
	 * 
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<SelectItem> getSelectList() {
		if (selectList == null) {
			selectList = new ArrayList<SelectItem>();

			this.clearItems();

			try {
				Collection objectCollection;

				if ((this.readMethodName != null) && readMethodParms == null) {
					objectCollection = (List) MethodUtils.invokeMethod(
							this.getService(), this.readMethodName, null);
				} else if ((this.readMethodName != null)
						&& readMethodParms != null) {
					objectCollection = (List) MethodUtils.invokeMethod(
							this.getService(), this.readMethodName,
							readMethodParms);
				} else {
					objectCollection = this.getService().findAll();
				}

				for (Object obj : objectCollection) {
					// 如果 showableValueSet 不等於 null
					// 而取出的 obj 的 value 不存在於 showableValueSet, 就不放進入選單
					if (showableValueSet != null) {
						if (!showableValueSet.contains(getObjValue(obj))) {
							continue;
						}
					}
					SelectItem item = this.generateSelectItem(obj);
					selectList.add(item);

				}

			} catch (Exception e) {
				LOG.error("fail in getSelectList", e);
			}
		}
		return selectList;
	}

	/**
	 * 取得目前的selectList
	 * 
	 * @return
	 */
	public List<SelectItem> getCurrentSelectList() {
		return selectList;
	}

	@SuppressWarnings("unchecked")
	public List<SelectItem> getDetailSelectList(String... masterIdArray) {
		if (selectList == null) {
			selectList = new ArrayList<SelectItem>();
		}

		clearItems();

		// FacesUtils.getSessionScope().put(mapName, map);

		List masterSelectedIdList = new ArrayList();

		for (String masterId : masterIdArray) {
			if (StringUtils.isNotBlank(masterId)
					&& StringUtils.isNumeric(masterId)) {
				masterSelectedIdList.add(Long.valueOf(masterId));
			} else if (StringUtils.isNotBlank(masterSelectHelper
					.getCurrentFirstValue())
					&& StringUtils.isNumeric(masterSelectHelper
							.getCurrentFirstValue())) {
				masterSelectedIdList.add(Long.valueOf(masterSelectHelper
						.getCurrentFirstValue()));
			}
		}

		try {
			// 透過 service, 傳入 master 的 id, 取出detail 的 vo
			if (masterSelectedIdList.size() == masterIdArray.length) {
				// if (masterSelectedIdList.size() > 0) {
				Collection detailBoCollection = (Collection) MethodUtils
						.invokeMethod(getService(), detailReaderName,
								masterSelectedIdList.toArray());
				for (Object detailBo : detailBoCollection) {
					SelectItem item = generateSelectItem(detailBo);
					selectList.add(item);

				}
			}
		} catch (Exception e) {
			LOG.error("fail in getDetailSelectList", e);
		}
		return selectList;
	}

	/**
	 * 依傳入的物件取得SelectItem
	 * 
	 * @param obj
	 * @return
	 * @throws Exception
	 */
	private SelectItem generateSelectItem(final Object obj) throws Exception {
		SelectItem item = new SelectItem();
		String value = this.getObjValue(obj).toString();
		item.setValue(value);
		item.setLabel(MethodUtils.invokeMethod(obj, labelGetterName, null)
				.toString());
		return item;
	}

	/**
	 * 依傳入的物件取得valueGetter Method的值
	 * 
	 * @param obj
	 * @return
	 * @throws Exception
	 */
	private Object getObjValue(final Object obj) throws Exception {
		return MethodUtils.invokeMethod(obj, valueGetterName, null);
	}

	/**
	 * 取得服務
	 * 
	 * @return
	 */
	private BaseService<?, ?> getService() {
		return (BaseService<?, ?>) ApplicationLocator.getApplicationContext()
				.getBean(serviceName);
	}

	/**
	 * 清除整個SelectHelper所包含的項目
	 *
	 */
	public void clearItems() {
		selectList.clear();
		selectList.add(EMPTY_SELECTITEM);
	}

	public String getCurrentFirstValue() {
		String result = "";
		if (selectList.size() > 0) {
			result = selectList.get(0).getValue().toString();
		}
		return result;
	}

}
