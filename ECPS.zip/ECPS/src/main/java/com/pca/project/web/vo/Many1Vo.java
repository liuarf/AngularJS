package com.pca.project.web.vo;

import java.util.ArrayList;
import java.util.List;

import javax.faces.model.ListDataModel;

import org.ajax4jsf.model.ExtendedDataModel;
import org.ajax4jsf.model.SequenceDataModel;

import com.pca.corefrmwk.web.vo.impl.ValueObjectImpl;
import com.pca.project.bo.Many1;
import com.pca.project.bo.Many2;

/**
 * Many1's Value Object Implement
 * 
 */
public class Many1Vo extends ValueObjectImpl<Many1, java.lang.String> {

	private static final long serialVersionUID = 1L;

	// DataModel裡面所wrap的List
	private List<Many2> many2List = null;
	// 頁面table binding的Model
	private ExtendedDataModel<Many2> many2DataModel;
	// 頁面table 的row是否選取binding的value
	private List<Object> many2SelectedRowKeys;

	/**
	 * Constructor
	 * 
	 */
	public Many1Vo() {
		super(new Many1());
	}

	/**
	 * Constructor
	 * 
	 * @param bo
	 *            Business Object
	 */
	public Many1Vo(Many1 bo) {
		super(bo);
	}

	/**
	 * 回傳Many2List
	 * 
	 * @return List<many2>
	 */
	public List<Many2> getMany2List() {
		return this.many2List;
	}

	/**
	 * 設定Many2List
	 * 
	 * @param many2List
	 */
	public void setMany2List(List<Many2> many2List) {
		this.many2List = many2List;
	}

	/**
	 * 回傳頁面上被勾選的Many2集合
	 * 
	 * @return List<Object>
	 */
	public List<Object> getMany2SelectedRowKeys() {
		if (this.many2SelectedRowKeys == null) {
			this.many2SelectedRowKeys = new ArrayList<Object>();
		}
		return this.many2SelectedRowKeys;
	}

	/**
	 * 設定頁面上被勾選的Item集合
	 * 
	 * @param Many2SelectedRowKeys
	 */
	public void setMany2SelectedRowKeys(List<Object> many2SelectedRowKeys) {
		this.many2SelectedRowKeys = many2SelectedRowKeys;
	}

	/**
	 * 回傳ItemDataModel
	 * 
	 * @return DataModel
	 */
	public ExtendedDataModel<Many2> getMany2DataModel() {
		if (this.many2DataModel == null) {

			this.many2DataModel = new SequenceDataModel<Many2>(
					new ListDataModel<Many2>());
			this.many2DataModel.setWrappedData(this.getMany2List());

		}
		return this.many2DataModel;

	}

	/**
	 * 設定Many2DataModel
	 * 
	 * @param many2DataModel
	 */
	public void setMany2DataModel(ExtendedDataModel<Many2> many2DataModel) {
		this.many2DataModel = many2DataModel;
	}

}
