package com.pca.project.dao.jpa;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Service;

import com.pca.corefrmwk.persistence.dao.jpa.BaseDaoImpl;
import com.pca.project.bo.Detail;
import com.pca.project.dao.DetailDao;

@Service("detailDao")
public class DetailDaoImpl extends BaseDaoImpl<Detail, java.lang.String>
		implements DetailDao {

	@PersistenceContext(unitName = "persistenceUnit")
	private EntityManager entityManager;

	/**
	 * 取得EntityManager
	 * 
	 * @return
	 */
	public EntityManager getEntityManager() {
		return this.entityManager;
	}

	/**
	 * 設定EntityManager
	 * 
	 * @param entityManager
	 */
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	/**
	 * 假如Entity(Business Object)，有Many-to-One或Many-to-Many的狀況， 則Code
	 * Generator會產生此Interface以供修改使用，可自行改成需要的Method，
	 * 主要作用是在read頁面就Fetch所有相關關聯的資料，免得再update頁面出現問題 p.s.如有master
	 * detail的狀況請自行加入Fetch
	 * 
	 * @return List<Detail>
	 */
	public List<Detail> findAllFetchRelation() {
		StringBuffer queryString = new StringBuffer();
		queryString.append("SELECT DISTINCT obj FROM Detail obj	");
		queryString.append("LEFT JOIN FETCH obj.master ");
		queryString.append("ORDER BY obj.id	");

		List<Detail> list = this.find(queryString);

		return list;
	}

}
