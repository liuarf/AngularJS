package com.pca.project.common.exception;

import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.persistence.OptimisticLockException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.transaction.TransactionSystemException;

import com.pca.project.common.ErrorCode;





@Aspect

public class ExceptionHandler {

    protected final Log logger = LogFactory.getLog(ExceptionHandler.class);

    @Pointcut("execution(* com.pca.project.service..*.*(..))")
    public void businessService() {
    }

    @Pointcut("(execution (public * com.pca.project.web.managedbean..*.do*(..)))")
    public void doActionInWebLayer() {
    }

    @AfterThrowing(pointcut = "businessService()", throwing = "ex")
    public void translateException(Throwable ex) {

    }

    @Around("doActionInWebLayer()")
    public Object handleUnprocessedException(ProceedingJoinPoint pjp) throws Throwable {
        try {
            return pjp.proceed();
        } catch (CompositeProjectRuntimeException e) {
            List<ProjectRuntimeException> exceptions = ((CompositeProjectRuntimeException) e).getExceptions();
            for (ProjectRuntimeException exception : exceptions) {
                this.handleException(exception);
            }
            return null;
        } catch (ProjectRuntimeException e) {
            this.handleException(e);
            return null;
        } catch (TransactionSystemException e) {
            this.handleException(e);
            return null;
        } catch (OptimisticLockException e) {
            ProjectRuntimeException throwable = new ProjectRuntimeException(ErrorCode.A10005, e);
            this.handleException(throwable);
            return null;
        } catch (OptimisticLockingFailureException e) {
            ProjectRuntimeException throwable = new ProjectRuntimeException(ErrorCode.A10005, e);
            this.handleException(throwable);
            return null;
        } catch (DataAccessException e) {
            this.handleException(e);
            return null;
        
        } catch (Exception e) {
            
            this.logger.error("Error msg = "+e.getMessage());
            e.printStackTrace();
            throw e;
        }
    }

    public void handleException(Throwable t) {
        FacesContext context = FacesContext.getCurrentInstance();
        this.logger.error(t.getMessage(), t);
        t.printStackTrace();
        if (t instanceof ProjectRuntimeException) {
            
            FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, t.getMessage(), t.getMessage());
            context.addMessage(((ProjectRuntimeException) t).getSourceId(), message);
        } else if (t instanceof TransactionSystemException) {
            FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, t.getMessage(), t.getMessage());
            context.addMessage(null, message);
        } else if (t instanceof OptimisticLockException) {
            FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, t.getMessage(), t.getMessage());
            context.addMessage(null, message);
        } else if (t instanceof OptimisticLockingFailureException) {
            FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, t.getMessage(), t.getMessage());
            context.addMessage(null, message);
        } else if (t instanceof DataAccessException) {
            FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, t.getMessage(), t.getMessage());
            context.addMessage(null, message);
        }
    }

}
