package com.pca.project.common.exception;

import java.util.ArrayList;
import java.util.List;


public class CompositeProjectRuntimeException extends RuntimeException {


    private static final long serialVersionUID = -6070213970238478319L;
    private List<ProjectRuntimeException> exceptions = new ArrayList<ProjectRuntimeException>();

    public List<ProjectRuntimeException> getExceptions() {
        return this.exceptions;
    }

    public void add(ProjectRuntimeException e) {
        this.exceptions.add(e);
    }

    public boolean hasException() {
        return exceptions.size() > 0;
    }

}
