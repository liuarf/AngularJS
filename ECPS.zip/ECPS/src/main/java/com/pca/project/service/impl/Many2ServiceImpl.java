package com.pca.project.service.impl;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pca.corefrmwk.service.impl.BaseServiceImpl;
import com.pca.project.bo.Many2;
import com.pca.project.dao.Many2Dao;
import com.pca.project.service.Many2Service;

@Service("many2Service")
public class Many2ServiceImpl extends
		BaseServiceImpl<Many2, java.lang.String, Many2Dao> implements
		Many2Service {

	@SuppressWarnings("unused")
	private final static Log LOG = LogFactory.getLog(Many2ServiceImpl.class);

	@Autowired
	private Many2Dao dao;

	/**
	 * 回傳Data Access Object
	 *
	 * @return many2Dao
	 */
	public Many2Dao getDao() {
		return this.dao;
	}

	/**
	 * 設定Data Access Object
	 *
	 * @param baseDao
	 */
	public void setDao(final Many2Dao baseDao) {
		this.dao = baseDao;
	}

	/**
	 * 假如Entity(Business Object)，有Many-to-One或Many-to-Many的狀況， 則Code
	 * Generator會產生此Interface以供修改使用，可自行改成需要的Method，
	 * 主要作用是在read頁面就Fetch所有相關關聯的資料，免得再update頁面出現問題
	 * 
	 * @return List<Many2>
	 */
	public List<Many2> findAllFetchRelation() {

		return this.getDao().findAllFetchRelation();
	}

}