/**
 * Copyright (c) 2012 PCA Life Assurance Co. Ltd. All Rights Reserved.
 */
package com.pca.project.util;

/**
 * Class Description:
 * 
 * @author pablo.sj.shen 2012/12/21 [PIS/SR NO.] [Comment]
 */
public enum CompType {
	EQUALS("="), GREATER_EQUALS(">="), LESS_EQUALS("<="), GREATER(">"), LESS(
			"<"), NOT_EQUALS("<>");

	private String text;

	CompType(String text) {
		this.text = text;
	}

	public String getText() {
		return this.text;
	}

	public static CompType fromString(String text) {
		if (text != null) {
			for (CompType b : CompType.values()) {
				if (text.equalsIgnoreCase(b.text)) {
					return b;
				}
			}
		}
		return null;
	}

}
