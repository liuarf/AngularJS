package com.pca.project.web.vowrapper;

import com.pca.corefrmwk.web.vowrapper.impl.VoWrapperImpl;
import com.pca.project.bo.Many1;
import com.pca.project.web.vo.Many1Vo;

/**
 * 轉換Many1為Many1Vo的Wrapper
 * 
 */
public class Many1VoWrapper extends VoWrapperImpl<Many1, java.lang.String> {

	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	@Override
	public Many1Vo wrap(Many1 bo) {
		return new Many1Vo(bo);
	}
}