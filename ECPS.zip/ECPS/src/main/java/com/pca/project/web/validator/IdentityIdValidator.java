package com.pca.project.web.validator;

import java.util.regex.Pattern;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.FacesValidator;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

import com.pca.corefrmwk.util.MessageManager;


/**
 * 身分證字號/居留證號檢核程式。
 *
 */
@FacesValidator("identityIdValidator")
public class IdentityIdValidator implements Validator {
    private MessageManager messageManager = MessageManager.getInstance();

    
    public void validate(FacesContext context, UIComponent component, Object value) throws ValidatorException {
        boolean validate = false;
        if (value != null) {
            String identityId = ((String) value).trim();
            if (identityId.length() == 10) {
                if (checkIdentityId(identityId) || checkIdentityIdAborad(identityId)) {
                    validate = true;
                }
            }
        }
        if (!validate) {
            FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, messageManager.getMessage("A10023"),
                    null);
            throw new ValidatorException(message);
        }
    }

    
    /**
     * 檢核身分證字號
     * 
     * @return
     */
    private boolean checkIdentityId(String identityId) {
    	identityId=identityId.toUpperCase();
        boolean tf = false;
        String domesticPattern = "[A-Za-z]{1}[0-9]{9}";
        if (Pattern.compile(domesticPattern).matcher(identityId).matches()) {
            String pre = "ABCDEFGHJKLMNPQRSTUVXYWZIO";
            String id = String.valueOf(pre.indexOf(identityId.substring(0, 1)) + 10) + identityId.substring(1, 10);
            int sum = Integer.parseInt(id.substring(0, 1)) + Integer.parseInt(id.substring(1, 2)) * 9
                    + Integer.parseInt(id.substring(2, 3)) * 8 + Integer.parseInt(id.substring(3, 4)) * 7
                    + Integer.parseInt(id.substring(4, 5)) * 6 + Integer.parseInt(id.substring(5, 6)) * 5
                    + Integer.parseInt(id.substring(6, 7)) * 4 + Integer.parseInt(id.substring(7, 8)) * 3
                    + Integer.parseInt(id.substring(8, 9)) * 2 + Integer.parseInt(id.substring(9, 10))
                    + Integer.parseInt(id.substring(10, 11));
            if (sum % 10 == 0) {
                tf = true;
            }
        }
        return tf;
    }

    
    /**
     * 檢核居留證號
     * 
     * @return
     */
    private boolean checkIdentityIdAborad(String identityId) {
    	identityId=identityId.toUpperCase();
        boolean tf = false;
        String abroadPattern = "[A-Za-z]{2}[0-9]{8}";
        if (Pattern.compile(abroadPattern).matcher(identityId).matches()) {
            String pre = "ABCDEFGHJKLMNPQRSTUVXYWZIO";
            String id = String.valueOf(pre.indexOf(identityId.substring(0, 1)) + 10)
                    + String.valueOf(pre.indexOf((identityId.substring(1, 2)) + 10) % 10) + identityId.substring(2, 10);
            int sum = Integer.parseInt(id.substring(0, 1)) + Integer.parseInt(id.substring(1, 2)) * 9
                    + Integer.parseInt(id.substring(2, 3)) * 8 + Integer.parseInt(id.substring(3, 4)) * 7
                    + Integer.parseInt(id.substring(4, 5)) * 6 + Integer.parseInt(id.substring(5, 6)) * 5
                    + Integer.parseInt(id.substring(6, 7)) * 4 + Integer.parseInt(id.substring(7, 8)) * 3
                    + Integer.parseInt(id.substring(8, 9)) * 2 + Integer.parseInt(id.substring(9, 10))
                    + Integer.parseInt(id.substring(10, 11));
            if (sum % 10 == 0) {
                tf = true;
            }
        }
        return tf;
    }
}
