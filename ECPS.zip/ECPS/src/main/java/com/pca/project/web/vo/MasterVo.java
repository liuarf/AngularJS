package com.pca.project.web.vo;

import com.pca.corefrmwk.web.vo.impl.ValueObjectImpl;
import com.pca.project.bo.Master;

/**
 * Master's Value Object Implement
 * 
 */
public class MasterVo extends ValueObjectImpl<Master, java.lang.String> {

	private static final long serialVersionUID = 1L;

	/**
	 * Constructor
	 * 
	 */
	public MasterVo() {
		super(new Master());
	}

	/**
	 * Constructor
	 * 
	 * @param bo
	 *            Business Object
	 */
	public MasterVo(Master bo) {
		super(bo);
	}

}
