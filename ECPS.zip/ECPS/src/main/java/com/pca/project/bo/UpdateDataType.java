/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.pca.project.bo;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Version;

import org.hibernate.annotations.GenericGenerator;

import com.pca.corefrmwk.persistence.jpa.entity.BaseBoImpl;

/**
 *
 * @author marvin.wc.hsu
 */
@Entity
@Table(name = "ZCFH")
@NamedQueries({
		@NamedQuery(name = "UpdateDataType.findAll", query = "SELECT u FROM UpdateDataType u ORDER BY u.name"),
		@NamedQuery(name = "UpdateDataType.findById", query = "SELECT u FROM UpdateDataType u WHERE u.id = :id"),
		@NamedQuery(name = "UpdateDataType.findByName", query = "SELECT u FROM UpdateDataType u WHERE u.name = :name"),
		@NamedQuery(name = "UpdateDataType.findByCode", query = "SELECT u FROM UpdateDataType u WHERE u.code = :code"),
		@NamedQuery(name = "UpdateDataType.findByVersion", query = "SELECT u FROM UpdateDataType u WHERE u.version = :version") })
public class UpdateDataType extends BaseBoImpl<String> {

	private static final long serialVersionUID = 8229513139070634843L;

	private String id;

	private String name;

	private String code;

	private int version;

	public UpdateDataType() {
	}

	public UpdateDataType(String name, String code) {

		this.name = name;
		this.code = code;
	}

	@Id
	@GeneratedValue(generator = "system-uuid")
	@GenericGenerator(name = "system-uuid", strategy = "uuid2")
	@Column(name = "KEYWORDS")
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	@Version
	@Column(name = "TSEQNO")
	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	@Basic(optional = false)
	@Column(name = "CANDSC")
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Basic(optional = false)
	@Column(name = "CHGDESC")
	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((code == null) ? 0 : code.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());

		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UpdateDataType other = (UpdateDataType) obj;
		if (code == null) {
			if (other.code != null)
				return false;
		} else if (!code.equals(other.code))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;

		return true;
	}

	@Override
	public String toString() {
		return "com.pca.newbizaid.persistence.domain.updateData.UpdateDataType[ id="
				+ this.getId() + " ]";
	}

}
