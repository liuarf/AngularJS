package com.pca.project.web.util;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;

public class ApplicationLocator implements ApplicationListener {
	public static ApplicationContext applicationContext;

	public void onApplicationEvent(final ApplicationEvent event) {
		if (event instanceof ContextRefreshedEvent) {
			applicationContext = ((ContextRefreshedEvent) event)
					.getApplicationContext();
		}
	}

	/**
	 * 取得ApplicationContext
	 * 
	 * @return
	 */
	public static ApplicationContext getApplicationContext() {
		return applicationContext;
	}

	/**
	 * 設定ApplicationContext
	 * 
	 * @param applicationContext
	 */
	public static void setApplicationContext(
			final ApplicationContext applicationContext) {
		ApplicationLocator.applicationContext = applicationContext;
	}

	/**
	 * 依名稱取得bean
	 * 
	 * @param name
	 * @return
	 */
	public static Object getBean(final String name) {
		return applicationContext.getBean(name);
	}
}
