package com.pca.project.bo;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.pca.corefrmwk.persistence.jpa.entity.BaseBoImpl;

@Entity
@Table(name = "DETAIL")
@NamedQueries({
		@NamedQuery(name = "Detail.findAll", query = "SELECT d FROM Detail d"),
		@NamedQuery(name = "Detail.findById", query = "SELECT d FROM Detail d WHERE d.id = :id"),
		@NamedQuery(name = "Detail.findByCode", query = "SELECT d FROM Detail d WHERE d.code = :code"),
		@NamedQuery(name = "Detail.findByName", query = "SELECT d FROM Detail d WHERE d.name = :name") })
public class Detail extends BaseBoImpl<String> {
	private static final long serialVersionUID = 1L;

	private String id;

	private String code;

	private String name;

	private Master master;

	public Detail() {
	}

	@Id
	@GeneratedValue(generator = "detail-uuid")
	@GenericGenerator(name = "detail-uuid", strategy = "uuid2")
	@Basic(optional = false)
	@Column(name = "ID")
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	@Basic(optional = false)
	@Column(name = "CODE")
	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	@Basic(optional = false)
	@Column(name = "NAME")
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@JoinColumn(name = "MASTER_ID", referencedColumnName = "ID")
	@ManyToOne(optional = false)
	public Master getMaster() {
		return master;
	}

	public void setMaster(Master master) {
		this.master = master;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((code == null) ? 0 : code.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Detail other = (Detail) obj;
		if (code == null) {
			if (other.code != null)
				return false;
		} else if (!code.equals(other.code))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}

}