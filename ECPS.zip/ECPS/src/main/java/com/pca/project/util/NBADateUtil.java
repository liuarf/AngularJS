/**
 * Copyright (c) 2012 PCA Life Assurance Co. Ltd. All Rights Reserved.
 */
package com.pca.project.util;

import java.text.ParseException;
import java.util.Date;

import com.pca.corefrmwk.util.DateUtil;

/**
 * Class Description: 把日期轉為int yyyyMMdd格式，若網件為null則回傳0 new Date(0)也為0
 * 
 * @author pablo.sj.shen 2012/12/18 [PIS/SR NO.] [Comment]
 */
public class NBADateUtil extends DateUtil {
	public static int parseDateToInt(Date date) {
		int returnInt = 0;
		if (date != null) {
			returnInt = Integer.parseInt(DateUtil
					.dateFormater(date, "yyyyMMdd"));
			if (returnInt == 19700101)
				returnInt = 0;
		}
		return returnInt;
	}

	/**
	 * 
	 * Method Description: 日期由字串轉為日期格式
	 * 
	 * @param objDate
	 * @return
	 * @throws ParseException
	 */
	public static Date parseStringObjToDate(Object objDate)
			throws ParseException {
		Date returnDate = null;
		if (objDate != null && objDate.toString().length() == 8) {
			String strDate = objDate.toString();
			returnDate = DateUtil.parseDate(strDate, "yyyyMMdd");
		}
		return returnDate;
	}

	/**
	 * 
	 * Method Description: 把民國年字串轉成日期格式
	 * 
	 * @param chineseDate
	 * @return
	 */
	public static Date parseChineseDateStringToDate(String chineseDate) {
		Date returnDate = null;

		if (chineseDate != null) {
			String numberFilter = "";
			for (int i = 0; i < chineseDate.length(); i++) {
				if (Character.isDigit(chineseDate.charAt(i))) {
					numberFilter = numberFilter + chineseDate.charAt(i);
				}
			}

			if (numberFilter.length() == 7) {
				int year = new Integer(numberFilter.substring(0, 3)) + 1911;
				int month = new Integer(numberFilter.substring(3, 5));
				int day = new Integer(numberFilter.substring(5, 7));
				returnDate = DateUtil.getDate(year, month, day).getTime();
			}
		}
		return returnDate;
	}

	public static String addSlahToChineseDateString(String chineseDate) {
		StringBuffer dateWithSlash = new StringBuffer();
		if (chineseDate != null && chineseDate.length() == 7) {
			dateWithSlash.append(chineseDate.substring(0, 3));
			dateWithSlash.append("/");
			dateWithSlash.append(chineseDate.substring(3, 5));
			dateWithSlash.append("/");
			dateWithSlash.append(chineseDate.substring(5, 7));
		}
		return dateWithSlash.toString();
	}

	/**
	 * 20140101 to 1030101
	 * 
	 * @param date
	 * @return
	 */
	public static String parseIntToChineseString(int date) {
		if (date < 10000000 || date == 0) {
			return String.valueOf(date);
		} else {
			int chd = date - 19110000;
			return String.valueOf(chd);
		}
	}

}
