package com.pca.project.web.managedbean.many1;

import java.net.InetAddress;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;

import com.pca.corefrmwk.context.AppContext;
import com.pca.corefrmwk.util.FacesUtils;
import com.pca.corefrmwk.util.MessageManager;
import com.pca.corefrmwk.web.managedbean.impl.TemplateDataTableManagedBean;
import com.pca.corefrmwk.web.session.content.UserInfo;
import com.pca.corefrmwk.web.vo.ValueObject;
import com.pca.corefrmwk.ws.AuditActionEmun;
import com.pca.corefrmwk.ws.AuditWSClient;
import com.pca.corefrmwk.ws.vo.AuditLogWSVO;
import com.pca.project.bo.Many1;
import com.pca.project.bo.Many2;
import com.pca.project.service.Many1Service;
import com.pca.project.service.Many2Service;
import com.pca.project.web.vo.Many1Vo;
import com.pca.project.web.vowrapper.Many1VoWrapper;

@ManagedBean
@SessionScoped
public class Many1ManagedBean extends
		TemplateDataTableManagedBean<Many1, java.lang.String, Many1Service> {

	private static final long serialVersionUID = 1L;

	// 新增或修改狀態，新增為Create，修改為Update，用於detail時返回正確路徑用
	private String mode;

	// managedBean的主要使用service
	@ManagedProperty(value = "#{many1Service}")
	private Many1Service service;

	// private List<SelectItem> many2List = null;
	@ManagedProperty(value = "#{many2Service}")
	private Many2Service many2Service;
	// 登入使用者
	@ManagedProperty(value = "#{userInfo}")
	private UserInfo userInfo;
	//建立auditlog的client
	@ManagedProperty(value = "#{auditWSClient}")
	private AuditWSClient auditWSClient;
		
	@ManagedProperty(value = "#{appContext}")
	private AppContext appContext;	
	/**
	 * 建構子
	 */
	public Many1ManagedBean() {

		super();

	}

	/**
	 * 初始設定
	 */
	@PostConstruct
	public void init() {
		// 設定是否一進頁面，即秀出資料
		this.setInitShowListData(true);
		// 初始話查詢條件
		this.initFindCriteriaMap();
		// 設定VoWrapper
		this.setVoWrapper(new Many1VoWrapper());

	}

	/**
	 * @return the mode
	 */
	public String getMode() {
		return mode;
	}

	/**
	 * @param mode
	 *            the mode to set
	 */
	public void setMode(String mode) {
		this.mode = mode;
	}

	/**
	 * 初始新增物件
	 * 
	 * @see com.pca.corefrmwk.web.managedbean.impl.BaseManagedBean#initCreatingData()
	 *
	 */
	@Override
	protected void initCreatingData() {
		Many1 object = new Many1();

		this.setUpdatingData(this.wrap(object));

		// 當頁面有多對多的check
		// box關係時，系統會呼叫this.getMany2List()，並將回傳值注入到this.updatingData
		this.getUpdatingData().setMany2List(this.getMany2List());
		this.setMode("Create");
	}

	/**
	 * 如需要再create or update按鈕按下後，對updating
	 * date進行處理，則需要撰寫此部分。但不管怎樣都需要override此method
	 * 
	 */
	@Override
	protected void initUpdatingData(
			ValueObject<Many1, java.lang.String> updatingData) {

		// 設定頁面上的項目勾選(Check Box for Many-to-many)
		this.getUpdatingData().setMany2List(this.getMany2List());
		Set<Many2> many2List = this.getUpdatingData().getBo().getMany2s();
		if (many2List != null && many2List.size() > 0) {
			for (int i = 0; i < this.getUpdatingData().getMany2DataModel()
					.getRowCount(); i++) {

				this.getUpdatingData().getMany2DataModel().setRowIndex(i);
				Many2 many2 = (Many2) this.getUpdatingData()
						.getMany2DataModel().getRowData();
				if (many2List.contains(many2)) {
					// 假如目前的many2已經是該Bo所關聯的的，則利用rowkeys，讓其在頁面勾選起來
					this.getUpdatingData()
							.getMany2SelectedRowKeys()
							.add(this.getUpdatingData().getMany2DataModel()
									.getRowKey());
				}
			}
		}

		this.setMode("Update");
	}

	/**
	 * 在read頁面下，如有查詢輸入時，則續在建構子呼叫此函數來設定findCriteriaMap 如需要可斟酌修改
	 * 
	 * @see com.pca.corefrmwk.web.managedbean.impl.TemplateDataTableManagedBean#initFindCriteriaMap()
	 */
	@Override
	protected void initFindCriteriaMap() {
		// 目前只能先用String
		Map<String, Object> findCriteriaMap = new HashMap<String, Object>();

		findCriteriaMap.put("name", null);

		findCriteriaMap.put("code", null);

		this.setFindCriteriaMap(findCriteriaMap);
		// 設定操作
		Map<String, String> findOperMap = new HashMap<String, String>();

		findOperMap.put("name", "eq");
		findOperMap.put("code", "eq");

		this.setFindOperMap(findOperMap);

		// 設定排序
		Map<String, String> findSortMap = new HashMap<String, String>();

		findSortMap.put("name", "DESC");
		findSortMap.put("code", "DESC");

		this.setFindSortMap(findSortMap);
	}

	/**
	 * getUpdatingData 和 setUpdatingData 其實可以不需要, 因為 super class 已經有了 存在的目的,
	 * 只是為了讓 IDE 知道它的確切的type為何, 讓 jsf 的頁面比較好拖拉
	 * 
	 * @see com.pca.corefrmwk.web.managedbean.impl.BaseManagedBean#getUpdatingData()
	 *
	 */
	@Override
	public Many1Vo getUpdatingData() {
		return (Many1Vo) super.getUpdatingData();
	}

	/**
	 * 設定UpdatingData
	 * 
	 */
	@Override
	public void setUpdatingData(ValueObject<Many1, java.lang.String> vo) {
		super.setUpdatingData(vo);
	}

	/**
	 * 取得Service物件
	 */
	public Many1Service getService() {

		return this.service;
	}

	/**
	 * 設定該ManagedBean的主要service
	 * 
	 * @param service
	 */
	public void setService(Many1Service service) {
		this.service = service;
	}

	public UserInfo getUserInfo() {
		return userInfo;
	}

	public void setUserInfo(UserInfo userInfo) {
		this.userInfo = userInfo;
	}

	public AuditWSClient getAuditWSClient() {
		return auditWSClient;
	}

	public void setAuditWSClient(AuditWSClient auditWSClient) {
		this.auditWSClient = auditWSClient;
	}

	public AppContext getAppContext() {
		return appContext;
	}

	public void setAppContext(AppContext appContext) {
		this.appContext = appContext;
	}

	/**
	 * manyToMany for Many2 回傳Many2清單選項，當頁面有多對多的check
	 * box關係時，系統會在initCreatingData與initUpdatingData使用此method
	 * ，並將回傳值注入到this.updatingData
	 * 
	 * @return List<Many2>
	 */
	public List<Many2> getMany2List() {

		List<Many2> manyBoList = new ArrayList<Many2>();

		// 要確認此 many bo 的 id 的型別是甚麼

		for (Many2 manyBo : getMany2Service().findAllFetchRelation()) {
			manyBoList.add(manyBo);

		}
		return manyBoList;
	}

	/**
	 * 回傳Many2Service
	 * 
	 * @return Many2Service
	 */
	public Many2Service getMany2Service() {
		return this.many2Service;
	}

	/**
	 * 設定Many2Service
	 * 
	 * @param Many2Service
	 */
	public void setMany2Service(Many2Service many2Service) {
		this.many2Service = many2Service;
	}

	// manyToMany for Many2 end

	/**
	 * 設定Many1所關聯的Many2
	 *
	 */
	@SuppressWarnings("unchecked")
	private void setupMany2() {

		if (this.getUpdatingData().getMany2List() != null) {
			List<Object> many2SelectedRowKeys = this.getUpdatingData()
					.getMany2SelectedRowKeys();
			this.getUpdatingData().getBo().clearMany2s();
			// 從聯繫的many2sSelectedRowKeySet中取出選取的部分
			Iterator<Object> many2SelectedRowKeyIterator = many2SelectedRowKeys
					.iterator();

			while (many2SelectedRowKeyIterator.hasNext()) {
				Object rowKey = many2SelectedRowKeyIterator.next();
				this.getUpdatingData().getMany2DataModel().setRowKey(rowKey);
				Many2 many2 = (Many2) this.getUpdatingData()
						.getMany2DataModel().getRowData();
				this.getUpdatingData().getBo().addMany2(many2);
			}
		}
	}

	/**
	 * @see com.pca.corefrmwk.web.managedbean.impl.BaseManagedBean#setupUpdatingData()
	 */
	@Override
	protected void setupUpdatingData() {

		this.setupMany2();
	}

	/**
	 * 假如Entity(Business Object)，有Many-to-One或Many-to-Many的狀況， 則Code
	 * Generator會自動Override以供修改使用，可自行改成需要的Method，
	 * 主要作用是在read頁面就Fetch所有相關關聯的資料，免得再update頁面出現問題
	 * 
	 * @see com.pca.corefrmwk.web.managedbean.impl.TemplateDataTableManagedBean#findAllData()
	 */
	@Override
	protected List<Many1> findAllData() {
		return this.getService().findAllFetchRelation();
	}

	/**
	 * 因Audit需求，覆寫此方法
	 * @see com.pca.corefrmwk.web.managedbean.impl.TemplateDataTableManagedBean#doSaveCreateAction()
	 */
	@Override
	public String doSaveCreateAction() {
		try {

			//以下為建立audit log範例
			AuditLogWSVO auditLogWSVO = new AuditLogWSVO();
			auditLogWSVO.setSystemId(this.getAppContext().getSystemID());
			auditLogWSVO.setFunctionId("Many1");
			auditLogWSVO.setFunctionName("Many1");
			auditLogWSVO.setLoginId(this.getUserInfo().getUserId());
			auditLogWSVO.setAuditActionEmun(AuditActionEmun.Create_Process);
			//取得client IP
			String clientIp=FacesUtils.getClientIp();
			auditLogWSVO.setSourceIP(clientIp);
			//取得主機IP
			InetAddress addr;
			
			addr = InetAddress.getLocalHost();
			String  requestHostIP = addr.getHostAddress();
			auditLogWSVO.setRequestHostIP(requestHostIP);
			
			this.getAuditWSClient().createAuditLog(auditLogWSVO);
			//以上為建立audit log範例
			
			return super.doSaveCreateAction();

		} catch (Exception ex) {
			
			MessageManager.getInstance().processExceptionMessage(ex);
			return null;

		}
	}
	
	/**
	 * 因Audit需求，覆寫此方法
	 * @see com.pca.corefrmwk.web.managedbean.impl.TemplateDataTableManagedBean#doSaveUpdateAction()
	 */
	@Override
	public String doSaveUpdateAction() {
		try {
			

			//以下為建立audit log範例
			AuditLogWSVO auditLogWSVO = new AuditLogWSVO();
			auditLogWSVO.setSystemId(this.getAppContext().getSystemID());
			auditLogWSVO.setFunctionId("Many1");
			auditLogWSVO.setFunctionName("Many1");
			auditLogWSVO.setLoginId(this.getUserInfo().getUserId());
			auditLogWSVO.setAuditActionEmun(AuditActionEmun.Update_Process);
			//取得client IP
			String clientIp=FacesUtils.getClientIp();
			auditLogWSVO.setSourceIP(clientIp);
			//取得主機IP
			InetAddress addr;
			
			addr = InetAddress.getLocalHost();
			String  requestHostIP = addr.getHostAddress();
			auditLogWSVO.setRequestHostIP(requestHostIP);
			
			this.getAuditWSClient().createAuditLog(auditLogWSVO);
			//以上為建立audit log範例
			
			return super.doSaveUpdateAction();

		} catch (Exception ex) {
			MessageManager.getInstance().processExceptionMessage(ex);
			return null;

		}
	}
	
	/**
	 * 因Audit需求，覆寫此方法
	 * @see com.pca.corefrmwk.web.managedbean.impl.TemplateDataTableManagedBean#doDeleteOneAction()
	 */
	@Override
	public String doDeleteOneAction() {
		try {
			
			//以下為建立audit log範例
			AuditLogWSVO auditLogWSVO = new AuditLogWSVO();
			auditLogWSVO.setSystemId(this.getAppContext().getSystemID());
			auditLogWSVO.setFunctionId("Many1");
			auditLogWSVO.setFunctionName("Many1");
			auditLogWSVO.setLoginId(this.getUserInfo().getUserId());
			auditLogWSVO.setAuditActionEmun(AuditActionEmun.Delete_Process);
			//取得client IP
			String clientIp=FacesUtils.getClientIp();
			auditLogWSVO.setSourceIP(clientIp);
			//取得主機IP
			InetAddress addr;
			
			addr = InetAddress.getLocalHost();
			String  requestHostIP = addr.getHostAddress();
			auditLogWSVO.setRequestHostIP(requestHostIP);
			
			this.getAuditWSClient().createAuditLog(auditLogWSVO);
			//以上為建立audit log範例
			
			return super.doDeleteOneAction();
		} catch (Exception ex) {
			MessageManager.getInstance().processExceptionMessage(ex);
			return null;

		}
	}
	
	
	/**
	 * 因Audit需求，覆寫此方法
	 * @see com.pca.corefrmwk.web.managedbean.impl.TemplateDataTableManagedBean#doFindAction()
	 */
	@Override
    public String doFindAction() {
		try {
			
			//以下為建立audit log範例
			AuditLogWSVO auditLogWSVO = new AuditLogWSVO();
			auditLogWSVO.setSystemId(this.getAppContext().getSystemID());
			auditLogWSVO.setFunctionId("Many1");
			auditLogWSVO.setFunctionName("Many1");
			auditLogWSVO.setLoginId(this.getUserInfo().getUserId());
			auditLogWSVO.setAuditActionEmun(AuditActionEmun.Inquery_Process);
			//取得client IP
			String clientIp=FacesUtils.getClientIp();
			auditLogWSVO.setSourceIP(clientIp);
			//取得主機IP
			InetAddress addr;
			
			addr = InetAddress.getLocalHost();
			String  requestHostIP = addr.getHostAddress();
			auditLogWSVO.setRequestHostIP(requestHostIP);
			
			this.getAuditWSClient().createAuditLog(auditLogWSVO);
			//以上為建立audit log範例
			
			return super.doFindAction();
		} catch (Exception ex) {
			MessageManager.getInstance().processExceptionMessage(ex);
			return null;

		}
    }
	
	
}
