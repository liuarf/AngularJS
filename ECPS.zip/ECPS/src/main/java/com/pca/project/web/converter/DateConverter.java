package com.pca.project.web.converter;

import java.util.Date;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;
import javax.faces.convert.FacesConverter;

import com.pca.corefrmwk.util.MessageManager;
import com.pca.project.common.ErrorCode;
import com.pca.project.util.DateUtils;
import com.pca.project.util.StringUtils;




/**
 * 日期轉換。
 *
 * 提供一個 Converter ，可以將Date轉換成日期格式(YYYMMDD)的民國年字串。
 *
 */
@FacesConverter("dateConverter")
public class DateConverter implements Converter {

    public Object getAsObject(FacesContext context, UIComponent component, String value) {
        Date d = null;
        boolean flag = false;
        try {
            if (StringUtils.isNotBlank(value)) {
                d = DateUtils.getDateByRocStr(value);
                flag = true;
            }
            if (d == null && flag) {
                throw new ConverterException();
            }
        } catch (Exception e) {
            FacesMessage message =
                new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                 MessageManager.getInstance().getMessage(ErrorCode.A10022.toString()), null);
            throw new ConverterException(message);
        }
        return d;
    }

    public String getAsString(FacesContext context, UIComponent component, Object value) {
        Date d = null;
        // 預設長度為7(YYYMMDD)
        int len = 7;
        try {
            String length = (String) component.getAttributes().get("length");
            if (length != null) {
                len = Integer.parseInt(length);
            }
        } catch (Exception e) {
            FacesMessage message =
                new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                 MessageManager.getInstance().getMessage(ErrorCode.A10007.toString(), new Object[] {
                                                                         "length" }), null);
            throw new ConverterException(message);
        }

        try {
            if (value == null) {
                return "";
            }
            d = (Date) value;
        } catch (Exception e) {
            FacesMessage message =
                new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                 MessageManager.getInstance().getMessage(ErrorCode.A10022.toString()), null);
            throw new ConverterException(message);
        }
        if (d == null) {
            return "";
        }
        return StringUtils.substring(StringUtils.leftPad(DateUtils.getROCDateStr(d, "", false), 7, "0"), 0,
                                     len);
    }

}
