package com.pca.project.job;

import java.util.Map.Entry;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Service;

import com.pca.schedule.exception.JobException;
import com.pca.schedule.scheduler.JobBaseIF;
import com.pca.schedule.scheduler.JobContext;
import com.pca.schedule.scheduler.Parameter;
import com.pca.schedule.scheduler.Status;
/**
 * 排程範例
 * @author marvin.wc.hsu
 * p.s.@Service("排程名稱")需與排程管理系統的設定相同
 */
@Service("simpleJobClass")
public class SimpleJobClass implements JobBaseIF{
	private static Log logger = LogFactory.getLog(SimpleJobClass.class);
	/**
	 * 排程執行的工作需寫在此方法
	 */
	@Override
	public void execute(JobContext context) throws JobException {
				
		logger.info("Simple Job Start");
		
		Parameter parameter = context.getScheduleParameter();
		for(Entry<String, String> param:parameter.entrySet()){
			logger.info("Schedule Parameter key="+param.getKey()+", value="+param.getValue());
		}
		
		
		logger.info("Simple Job Down");
		
		//回傳回排程管理系統的job執行結果
		context.setResult("Simple Job Down");
		context.setStatus(Status.SUCCEEDED);
	}

}
