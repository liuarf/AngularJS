package com.pca.project.common.exception;

import javax.persistence.OptimisticLockException;

import org.springframework.dao.DataAccessException;

import com.pca.project.common.ErrorCode;

/**
 * 轉換所有 Exception 為 ProjectException
 *
 *
 */
public class ProjectExceptionTranslator {

    private ProjectExceptionTranslator() {
    }


    /**
     * 轉換Exception為ExpException
     * @param Throwable t
     * @return ProjectException
     */
    public static ProjectException translatingException(Throwable t) {

        ErrorCode errorCode = ErrorCode.A10004; //預設為未知的錯誤
        String[] params = null;

        if (t instanceof ProjectException) {
            return (ProjectException) t;
        }
        //同一筆資料同時被寫入
        if (t instanceof OptimisticLockException) {
            errorCode = ErrorCode.A10005;
        }
        //資料存取錯誤
        else if (t instanceof DataAccessException) {
            errorCode = ErrorCode.A10021;
        }


        ProjectException ex = new ProjectException(errorCode, params, t);

        return ex;
    }

}
