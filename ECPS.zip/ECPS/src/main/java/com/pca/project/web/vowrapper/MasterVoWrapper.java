package com.pca.project.web.vowrapper;

import com.pca.corefrmwk.web.vowrapper.impl.VoWrapperImpl;
import com.pca.project.bo.Master;
import com.pca.project.web.vo.MasterVo;

/**
 * 轉換Master為MasterVo的Wrapper
 * 
 */
public class MasterVoWrapper extends VoWrapperImpl<Master, java.lang.String> {

	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	@Override
	public MasterVo wrap(Master bo) {
		return new MasterVo(bo);
	}
}