package com.pca.project.util;

import java.util.LinkedHashMap;
import java.util.Map;

public enum UploadFileRule {
	/**
	 * 1.職域 WSyyymmdd.xlsx<br>
	 * 1.1家扶 WS1yyymmdd.xlsx<br>
	 * 2.電銷 TM+[BC]{1}+電銷代碼{5}+_yyyymmdd.csv<br>
	 * 3.渣打 SCBEPAAyyyymmdd01.txt or SCBPAyyyymmdd01.xlsx<br>
	 * 4.玉山 SETLDyyyymmddhhmmss.203.txt<br>
	 * 5.其他銀行 TBC 其他銀行還沒確認<br>
	 */
	WS("職域", "A", "09WSM", 1), 
	WS1("職域_家扶", "A", "09WSM", 1), 
	TMB("電銷_自有", "B","", 2), 
	TMC("電銷_委外", "C", "", 2), 
	EAPP("渣打", "D", "09AM1", 3),
	SCBPA("渣打", "D", "09AM1", 4), 
	SETLD("玉山", "D", "09AJ1", 5); 
	// TBC("", "","", 0,"");
	UploadFileRule(String sndsrcCh, String sndsrc, String zrsecno01, int rule) {
		this.sndsrcCh = sndsrcCh;
		this.sndsrc = sndsrc;
		this.zrsecno01 = zrsecno01;
		this.rule = rule;

	}

	// 來源中文
	private String sndsrcCh;
	// 定義擷取
	private int rule;
	// 檔案格式
	private String format;
	/**
	 * 來源<br>
	 * 職域: A.職域行銷 <br>
	 * 電銷: B.自有/C.委外 <br>
	 * 渣打/玉山:D.保經代通路<br>
	 */
	private String sndsrc;
	/**
	 * 行銷人員一<br>
	 * 渣打:09AM1<br>
	 * 職域:09WSM <br>
	 * 玉山:09AJ1<br>
	 * 電銷:檔名 5碼電銷代碼<br>
	 */
	private String zrsecno01;
	// 上傳檔案名稱
	private String jobnote;

	/**
	 * 依檔名帶出對應匯入來源
	 * 
	 * @param name
	 *            檔名
	 * @return UploadFileRule(來源)
	 */
	public static UploadFileRule findMappingByName(String name) {
		for (UploadFileRule item : UploadFileRule.values()) {
			if (name.startsWith(item.name())) {
				return item;
			}
		}
		return null;
	}

	/**
	 * 取得需要爛位
	 * 
	 * @param uploadFileRule
	 * @param name
	 *            檔名
	 * @return Map<String, Object>
	 */
	public Map<String, Object> toTakeRule(UploadFileRule uploadFileRule,
			String name) {
		Map<String, Object> tmMap = new LinkedHashMap<String, Object>();
		this.jobnote = name;
		//取得副檔名
		this.format = name.split("\\.").length > 1 ? name.split("\\.")[1] : "";
		// 電銷
		if (name.startsWith("TM")) {
			this.zrsecno01 = name.substring(3, 8);
		}
		getKey(tmMap);
		// 依上傳來源找出所需要的欄位及讀檔方式
		switch (uploadFileRule.rule) {
		case 1:
			ruleOfCase1(tmMap);
			break;
		case 2:
			ruleOfCase2(tmMap);
			break;
		case 3:
			ruleOfCase3(tmMap);
			break;
		case 4:
			ruleOfCase4(tmMap);
			break;
		case 5:
			ruleOfCase5(tmMap);
			break;
		default:
			break;

		}
		return tmMap;
	}

	private void getKey(Map<String, Object> tmMap) {
		// 檔名取得
		tmMap.put("sndsrc", this.getSndsrc());// 來源(*)
		tmMap.put("zrsecno01", this.getZrsecno01());// 行銷人員一
		tmMap.put("jobnote", this.getJobnote());// 上傳檔案名稱
		// 各個檔案
		tmMap.put("caseno", null);// 受理編號(*)
		tmMap.put("appldate", null);// 要保日期(*)
		tmMap.put("cownid", null);// 要保人ID
		tmMap.put("ownname", null);// 要保人姓名
		tmMap.put("zcowndob", null);// 要保人生日
		tmMap.put("lifeid", null);// 被保險人ID(*)
		tmMap.put("zlifname", null);// 被保險人姓名
		tmMap.put("zlfdob", null);// 被保人生日
		tmMap.put("sex", null);// 被保人性別
		tmMap.put("liferel", null);// 要、被保險人關係
		tmMap.put("crtable", null);// 商品代碼(*)
		//==============
		tmMap.put("polpln", null);//險種
		//==============
		tmMap.put("billfreq", null);// 繳別
		tmMap.put("sumins", null);// 保額(*)
		tmMap.put("instprem", null);// 保費
		tmMap.put("zrsecno02", null);// 經攬人員編
		tmMap.put("recuser", null);// 保經代公司代碼

	}

	/**
	 * 
	 * 職域 WSyyymmdd.xlsx,家扶 WS1yyymmdd.xlsx
	 * 
	 * @param tmMap
	 */
	private void ruleOfCase1(Map<String, Object> tmMap) {
		tmMap.put("caseno", 1);//(*)
		tmMap.put("appldate", 5);//(*)
		tmMap.put("lifeid", 3);//(*)
		tmMap.put("zlifname", 2);
		tmMap.put("zlfdob", 4);
		tmMap.put("billfreq", 8);
		tmMap.put("sumins", 7);//(*)
		tmMap.put("instprem", 9);
		// join TABLE EUFDPF.POLPLN 帶 crtable
		tmMap.put("polpln", 6);
		//tmMap.put("crtable", "");//(*)
	}

	/**
	 * 電銷 TM+[BC]{1}+電銷代碼{5}+_yyyymmdd.csv
	 * 
	 * @param tmMap
	 */
	private void ruleOfCase2(Map<String, Object> tmMap) {
		tmMap.put("caseno", 30);//(*)
		tmMap.put("appldate", 10);//(*)
		tmMap.put("cownid", 6);
		tmMap.put("ownname", 5);
		tmMap.put("zcowndob", 7);
		tmMap.put("lifeid", 2);//(*)
		tmMap.put("zlifname", 1);
		tmMap.put("zlfdob", 3);
		tmMap.put("sex", 4);
		tmMap.put("liferel", 9);
		tmMap.put("billfreq", 11);
		// 主/附約都要帶,每個險種一筆資料
		// 2碼年期+險種英文代碼
		//join TABLE EUFDPF.POLPLN 帶 crtable
		tmMap.put("polpln", 12);
		//tmMap.put("crtable", "");//(*)
		tmMap.put("sumins", 18);//(*)
		tmMap.put("instprem", 24);
		tmMap.put("polpln1", 13);
		//tmMap.put("crtable1", "");
		tmMap.put("sumins1", 19);
		tmMap.put("instprem1", 25);
		tmMap.put("polpln2", 14);
		//tmMap.put("crtable2", "");
		tmMap.put("sumins2", 20);
		tmMap.put("instprem2", 26);
		tmMap.put("polpln3", 15);
		//tmMap.put("crtable3", "");
		tmMap.put("sumins3", 21);
		tmMap.put("instprem3", 27);
		tmMap.put("polpln4", 16);
		//tmMap.put("crtable4", "");
		tmMap.put("sumins4", 22);
        tmMap.put("instprem4", 28);
        tmMap.put("polpln5", 17);
		//tmMap.put("crtable5", "");
		tmMap.put("sumins5", 23);
		tmMap.put("instprem5", 29);

	}

	/**
	 * 渣打 SCBEPAAyyyymmdd01.txt
	 * 
	 * @param tmMap
	 */
	private void ruleOfCase3(Map<String, Object> tmMap) {
		tmMap.put("appldate", new Object[] { "POL", 11, 19 });//(*)
		tmMap.put("billfreq", new Object[] { "POL", 25, 27 });
		tmMap.put("zrsecno02", new Object[] { "POL", 57, 79 });
		tmMap.put("caseno", new Object[] { "COV", 3, 13 });//(*)
		tmMap.put("lifeid", new Object[] { "COV", 27, 51 });//(*)
		//險種代碼join TABLE EUFDPF.POLPLN 帶 crtable
		tmMap.put("polpln", new Object[] { "COV", 17, 27 });
		//tmMap.put("crtable", "");//(*)
		tmMap.put("sumins", new Object[] { "COV", 51, 68 });//(*)
		// roleflag = 1=========================
		tmMap.put("roleflag", new Object[] { "PER", 5, 6 });
		tmMap.put("cownid", new Object[] { "PER", 6, 30 });
		tmMap.put("ownname", new Object[] { "PER", 32, 47 });
		tmMap.put("zcowndob", new Object[] { "PER", 47, 55 });
		tmMap.put("liferel", new Object[] { "PER", 56, 57 });
		// lifeid join cownid====================
		tmMap.put("zlifname", new Object[] { "PER", 32, 47 });
		tmMap.put("zlfdob", new Object[] { "PER", 47, 55 });
		tmMap.put("sex", new Object[] { "PER", 30, 31 });
		// ======================================

	}

	/**
	 * 渣打 SCBPAyyyymmdd01.xlsx
	 * 
	 * @param tmMap
	 */
	private void ruleOfCase4(Map<String, Object> tmMap) {
		tmMap.put("caseno", 5);//(*)
		tmMap.put("appldate", 4);//0104/06/01//(*)
		tmMap.put("lifeid", 0);//(*)
		tmMap.put("sumins", 3);//(*)
		tmMap.put("zlfdob", 1);//0058/01/01
		tmMap.put("instprem", 7);
		// 險種名稱 join LA12PF.ZPLONGC
		tmMap.put("zplongc", 2);
		//tmMap.put("crtable", "");//(*)
	}

	/**
	 * 玉山 SETLDyyyymmddhhmmss.203.txt(,分隔)
	 * 
	 * @param tmMap
	 */
	private void ruleOfCase5(Map<String, Object> tmMap) {
		tmMap.put("caseno", 2);//(*)
		tmMap.put("appldate", 4);//(*)
		tmMap.put("cownid", 5);
		tmMap.put("zcowndob", 6);
		tmMap.put("lifeid", 7);//(*)
		tmMap.put("zlfdob", 8);
		tmMap.put("crtable", 13);//(*)
		tmMap.put("billfreq", 17);
		tmMap.put("sumins", 19);//(*)
		tmMap.put("instprem", 21);
		tmMap.put("zrsecno02", 11);
		tmMap.put("recuser", 0);
	}

	public String getSndsrc() {
		return sndsrc;
	}

	public void setSndsrc(String sndsrc) {
		this.sndsrc = sndsrc;
	}

	public String getSndsrcCh() {
		return sndsrcCh;
	}

	public void setSndsrcCh(String sndsrcCh) {
		this.sndsrcCh = sndsrcCh;
	}

	public int getRule() {
		return rule;
	}

	public void setRule(int rule) {
		this.rule = rule;
	}

	public String getZrsecno01() {
		return zrsecno01;
	}

	public void setZrsecno01(String zrsecno01) {
		this.zrsecno01 = zrsecno01;
	}

	public String getJobnote() {
		return jobnote;
	}

	public void setJobnote(String jobnote) {
		this.jobnote = jobnote;
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

}
