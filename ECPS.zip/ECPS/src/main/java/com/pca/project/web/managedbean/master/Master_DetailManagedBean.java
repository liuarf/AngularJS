package com.pca.project.web.managedbean.master;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;

import com.pca.corefrmwk.util.MessageManager;
import com.pca.corefrmwk.web.managedbean.impl.TemplateDataTableManagedBean;
import com.pca.corefrmwk.web.vo.ValueObject;
import com.pca.project.bo.Detail;
import com.pca.project.service.DetailService;
import com.pca.project.web.vo.DetailVo;
import com.pca.project.web.vowrapper.DetailVoWrapper;

@ManagedBean
@SessionScoped
public class Master_DetailManagedBean extends
		TemplateDataTableManagedBean<Detail, java.lang.String, DetailService> {

	private static final long serialVersionUID = 1L;

	@ManagedProperty(value = "#{masterManagedBean}")
	private MasterManagedBean masterManagedBean;

	// managedBean的主要使用service
	@ManagedProperty(value = "#{detailService}")
	private DetailService service;

	/**
	 * 建構子
	 */
	public Master_DetailManagedBean() {

		super();

	}

	/**
	 * 初始設定
	 */
	@PostConstruct
	public void init() {
		// 設定是否一進頁面，即秀出資料
		this.setInitShowListData(true);
		// 初始話查詢條件
		this.initFindCriteriaMap();
		// 設定VoWrapper
		this.setVoWrapper(new DetailVoWrapper());

	}

	public MasterManagedBean getMasterManagedBean() {
		return this.masterManagedBean;
	}

	public void setMasterManagedBean(MasterManagedBean masterManagedBean) {
		this.masterManagedBean = masterManagedBean;
	}

	/**
	 * 初始新增物件
	 * 
	 * @see com.pca.corefrmwk.web.managedbean.impl.BaseManagedBean#initCreatingData()
	 *
	 */
	@Override
	protected void initCreatingData() {
		Detail object = new Detail();

		this.setUpdatingData(this.wrap(object));

	}

	/**
	 * 如需要再create or update按鈕按下後，對updating
	 * date進行處理，則需要撰寫此部分。但不管怎樣都需要override此method
	 * 
	 */
	@Override
	protected void initUpdatingData(
			ValueObject<Detail, java.lang.String> updatingData) {

	}

	/**
	 * 在read頁面下，如有查詢輸入時，則續在建構子呼叫此函數來設定findCriteriaMap 如需要可斟酌修改
	 * 
	 * @see com.pca.corefrmwk.web.managedbean.impl.TemplateDataTableManagedBean#initFindCriteriaMap()
	 */
	@Override
	protected void initFindCriteriaMap() {
		// 目前只能先用String
		Map<String, Object> findCriteriaMap = new HashMap<String, Object>();

		findCriteriaMap.put("name", null);

		findCriteriaMap.put("code", null);

		this.setFindCriteriaMap(findCriteriaMap);
		// 設定操作
		Map<String, String> findOperMap = new HashMap<String, String>();

		findOperMap.put("name", "eq");
		findOperMap.put("code", "eq");

		this.setFindOperMap(findOperMap);

		// 設定排序
		Map<String, String> findSortMap = new HashMap<String, String>();

		findSortMap.put("name", "DESC");
		findSortMap.put("code", "DESC");

		this.setFindSortMap(findSortMap);
	}

	/**
	 * getUpdatingData 和 setUpdatingData 其實可以不需要, 因為 super class 已經有了 存在的目的,
	 * 只是為了讓 IDE 知道它的確切的type為何, 讓 jsf 的頁面比較好拖拉
	 * 
	 * @see com.pca.corefrmwk.web.managedbean.impl.BaseManagedBean#getUpdatingData()
	 *
	 */
	@Override
	public DetailVo getUpdatingData() {
		return (DetailVo) super.getUpdatingData();
	}

	/**
	 * 設定UpdatingData
	 * 
	 */
	@Override
	public void setUpdatingData(ValueObject<Detail, java.lang.String> vo) {
		super.setUpdatingData(vo);
	}

	/**
	 * 取得Service物件
	 */
	public DetailService getService() {

		return this.service;
	}

	/**
	 * 設定該ManagedBean的主要service
	 * 
	 * @param service
	 */
	public void setService(DetailService service) {
		this.service = service;
	}

	/**
	 * @see com.pca.corefrmwk.web.managedbean.impl.BaseManagedBean#setupUpdatingData()
	 */
	@Override
	protected void setupUpdatingData() {

	}

	/**
	 * 
	 */
	@Override
	protected List<Detail> findAllData() {

		Set<Detail> set = this.getMasterManagedBean().getUpdatingData().getBo()
				.getDetails();
		List<Detail> list = new ArrayList<Detail>();
		if (set != null && set.size() > 0) {
			for (Detail detail : set) {
				list.add(detail);
			}
		}
		return list;
	}

	/**
	 * @see com.pca.corefrmwk.web.managedbean.impl.TemplateDataTableManagedBean#doCreateAction()
	 */
	@Override
	public String doCreateAction() {
		// 呼叫父層方法
		super.doCreateAction();
		return "createDetail";
	}

	/**
	 * @see com.pca.corefrmwk.web.managedbean.impl.TemplateDataTableManagedBean#doCancelCreateAction()
	 */
	@Override
	public String doCancelCreateAction() {
		// 呼叫父層方法
		super.doCancelCreateAction();
		if (this.getMasterManagedBean().getMode().equals("Create")) {
			return "readCreate";
		} else {
			return "readUpdate";
		}
	}

	/**
	 * @see com.pca.corefrmwk.web.managedbean.impl.TemplateDataTableManagedBean#doSaveCreateAction()
	 */
	@Override
	public String doSaveCreateAction() {
		try {
			// 這邊主要是設定物件的相關關聯與其他有的沒的
			this.setupUpdatingData();

			// 假如關聯集為null則初始化
			if (this.getMasterManagedBean().getUpdatingData().getBo()
					.getDetails() == null) {
				this.getMasterManagedBean().getUpdatingData().getBo()
						.setDetails(new LinkedHashSet<Detail>());
			}

			// 把資料塞到master managedbean的新增修改物件裡
			this.getMasterManagedBean().getUpdatingData().getBo()
					.addDetail(this.getUpdatingData().getBo());

			// 重整頁面
			this.doRefreshData();

			// 依模式導回父層新增或修改頁面
			if (this.getMasterManagedBean().getMode().equals("Create")) {
				return "readCreate";
			} else {
				return "readUpdate";
			}

		} catch (Exception ex) {
			MessageManager.getInstance().processExceptionMessage(ex);
			return null;

		}
	}

	/**
	 * @see com.pca.corefrmwk.web.managedbean.impl.TemplateDataTableManagedBean#doUpdateAction()
	 */
	public String doUpdateAction() {
		// 呼叫父層方法
		super.doUpdateAction();
		return "updateDetail";
	}

	/**
	 * @see com.pca.corefrmwk.web.managedbean.impl.TemplateDataTableManagedBean#doSaveUpdateAction()
	 */
	@Override
	public String doSaveUpdateAction() {
		try {
			// 這邊主要是設定物件的相關關聯與其他有的沒的
			this.setupUpdatingData();

			// 假如關聯集為null則初始化
			if (this.getMasterManagedBean().getUpdatingData().getBo()
					.getDetails() == null) {
				this.getMasterManagedBean().getUpdatingData().getBo()
						.setDetails(new LinkedHashSet<Detail>());
			}

			// 把資料塞到master managedbean的新增修改物件裡
			this.getMasterManagedBean().getUpdatingData().getBo()
					.addDetail(this.getUpdatingData().getBo());

			// 重整頁面
			this.doRefreshData();

			// 依模式導回父層新增或修改頁面
			if (this.getMasterManagedBean().getMode().equals("Create")) {
				return "readCreate";
			} else {
				return "readUpdate";
			}

		} catch (Exception ex) {
			MessageManager.getInstance().processExceptionMessage(ex);
			return null;

		}
	}

	/**
	 * @see com.pca.corefrmwk.web.managedbean.impl.TemplateDataTableManagedBean#doCancelUpdateAction()
	 */
	@Override
	public String doCancelUpdateAction() {
		// 呼叫父層方法
		super.doCancelUpdateAction();
		if (this.getMasterManagedBean().getMode().equals("Create")) {
			return "readCreate";
		} else {
			return "readUpdate";
		}
	}

	/**
	 * @see com.pca.corefrmwk.web.managedbean.impl.TemplateDataTableManagedBean#doDeleteOneAction()
	 */
	@Override
	public String doDeleteOneAction() {
		try {
			// 把資料塞到master managedbean的新增修改物件裡
			this.getMasterManagedBean().getUpdatingData().getBo()
					.removeDetail(this.getUpdatingData().getBo());

			// 重整頁面
			this.doRefreshData();

			// 依模式導回父層新增或修改頁面
			if (this.getMasterManagedBean().getMode().equals("Create")) {
				return "readCreate";
			} else {
				return "readUpdate";
			}
		} catch (Exception ex) {
			MessageManager.getInstance().processExceptionMessage(ex);
			return null;

		}
	}
}
