package com.pca.project.service.impl;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pca.corefrmwk.service.impl.BaseServiceImpl;
import com.pca.project.bo.Many1;
import com.pca.project.dao.Many1Dao;
import com.pca.project.service.Many1Service;

@Service("many1Service")
public class Many1ServiceImpl extends
		BaseServiceImpl<Many1, java.lang.String, Many1Dao> implements
		Many1Service {

	@SuppressWarnings("unused")
	private final static Log LOG = LogFactory.getLog(Many1ServiceImpl.class);

	@Autowired
	private Many1Dao dao;

	/**
	 * 回傳Data Access Object
	 *
	 * @return many1Dao
	 */
	public Many1Dao getDao() {
		return this.dao;
	}

	/**
	 * 設定Data Access Object
	 *
	 * @param baseDao
	 */
	public void setDao(final Many1Dao baseDao) {
		this.dao = baseDao;
	}

	/**
	 * 假如Entity(Business Object)，有Many-to-One或Many-to-Many的狀況， 則Code
	 * Generator會產生此Interface以供修改使用，可自行改成需要的Method，
	 * 主要作用是在read頁面就Fetch所有相關關聯的資料，免得再update頁面出現問題
	 * 
	 * @return List<Many1>
	 */
	public List<Many1> findAllFetchRelation() {

		return this.getDao().findAllFetchRelation();
	}

}