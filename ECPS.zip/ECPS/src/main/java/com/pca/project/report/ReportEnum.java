package com.pca.project.report;

public enum ReportEnum {
	C0109001 {
		public String toString() {
			return "C0109001";
		}
	}
	;
}
