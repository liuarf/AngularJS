package com.pca.project.bo;

import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.pca.corefrmwk.persistence.jpa.entity.BaseBoImpl;

/**
 * The persistent class for the MANY2 database table.
 * 
 */
@Entity
@Table(name = "MANY2")
@NamedQuery(name = "Many2.findAll", query = "SELECT m FROM Many2 m")
public class Many2 extends BaseBoImpl<String> {
	private static final long serialVersionUID = 1L;
	private String id;
	private String code;
	private String name;
	private Set<Many1> many1s;

	public Many2() {
	}

	@Id
	@GeneratedValue(generator = "many2-uuid")
	@GenericGenerator(name = "many2-uuid", strategy = "uuid2")
	@Basic(optional = false)
	@Column(name = "ID")
	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	@Basic(optional = false)
	@Column(name = "CODE")
	public String getCode() {
		return this.code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	@Basic(optional = false)
	@Column(name = "NAME")
	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	// bi-directional many-to-many association to Function
	@ManyToMany(mappedBy = "many2s", fetch = FetchType.LAZY, targetEntity = Many1.class)
	public Set<Many1> getMany1s() {
		return many1s;
	}

	public void setMany1s(Set<Many1> many1s) {
		this.many1s = many1s;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((code == null) ? 0 : code.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Many2 other = (Many2) obj;
		if (code == null) {
			if (other.code != null)
				return false;
		} else if (!code.equals(other.code))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}

}