package com.pca.project.web.managedbean;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;
import javax.faces.event.ActionEvent;
import javax.servlet.http.HttpSession;

import com.pca.corefrmwk.authentication.context.AuthorityContext;
import com.pca.corefrmwk.authentication.context.FunctionContext;
import com.pca.corefrmwk.authentication.context.ModuleContext;
import com.pca.corefrmwk.authentication.context.TransactionContext;
import com.pca.corefrmwk.authentication.util.AuthorityUtil;
import com.pca.corefrmwk.context.AppContext;
import com.pca.corefrmwk.util.FacesUtils;
import com.pca.corefrmwk.web.session.content.UserInfo;

/**
 * 控制左邊功能列表的ManagedBean
 * 
 * @author marvin.wc.hsu
 *
 */
@ManagedBean
@SessionScoped
public class MenuManagedBean implements Serializable {

	private static final long serialVersionUID = -4355556086188442433L;

	@ManagedProperty(value = "#{appContext}")
	private AppContext appContext;

	@ManagedProperty(value = "#{authorityUtil}")
	private AuthorityUtil authorityUtil;

	@ManagedProperty(value = "#{userInfo}")
	private UserInfo userInfo;

	private AuthorityContext authorityContext;
	// 保留選取哪個tab的變數
	private String activeTab;

	public MenuManagedBean() {
		super();

	}

	@PostConstruct
	public void init() {

		//String systemId = FacesUtils.getRequestParamValue("systemId");
		//String userId = FacesUtils.getRequestParamValue("userId");
		// 取得系統代號
        String systemId = this.getAppContext().getSystemID();
        // 取得使用者代號
        String userId = FacesUtils.getHttpServletRequest().getUserPrincipal().getName();
		HttpSession session = FacesUtils.getHttpSession();
		boolean result = this.getAuthorityUtil().initialSystem(session,
				systemId, userId);

		if (result) {
			AuthorityContext context = (AuthorityContext) session
					.getAttribute(AuthorityContext.CONST_USER_AUTHORITY);
			this.getUserInfo().setUserId(context.getUserId());
			this.getUserInfo().setUserName(context.getUserName());
			this.getUserInfo().setUserDeptId(context.getUnitId());
			this.getUserInfo().setUserDept(context.getUnitName());
			this.getUserInfo().setUserTelNo(context.getTel());
			this.getUserInfo().setUserTelExt(context.getExt());

			this.setAuthorityContext(context);

		} else {
			// todo 記得座島頁到無權限
		}

	}

	/**
	 * 左邊頁面功能列的modules
	 * 
	 * @return
	 */
	public List<ModuleContext> getModules() {

		return this.getAuthorityContext().getModules();

	}

	public void navigationListener(ActionEvent event) throws Exception {
		String functionOutcome = (String) event.getComponent().getAttributes()
				.get("functionOutcome");
		// 點選左邊選單時移除存在session的managedbean，以讓畫面從置
		FacesUtils.getFacesContext().getExternalContext().getSessionMap()
				.remove(functionOutcome + "ManagedBean");
	}

	/**
	 * 判斷是否有權限，沒權限就傳回false，有權限就傳回true
	 * 
	 * @return
	 */
	public boolean isGrant(String transactionCode, String functionCode) {

		for (ModuleContext module : this.getAuthorityContext().getModules()) {
			for (TransactionContext transaction : module.getTransactions()) {
				if (transaction.getTransactionCode().equals(transactionCode)) {
					for (FunctionContext function : transaction.getFunctions()) {
						if (function.getFunction().equals(functionCode)) {
							return true;
						}

					}
				}

			}

		}
		// 跑到這代表沒符合的功能可用，故回傳false
		return false;
	}

	public AppContext getAppContext() {
		return appContext;
	}

	public void setAppContext(AppContext appContext) {
		this.appContext = appContext;
	}

	public AuthorityUtil getAuthorityUtil() {
		return authorityUtil;
	}

	public void setAuthorityUtil(AuthorityUtil authorityUtil) {
		this.authorityUtil = authorityUtil;
	}

	public UserInfo getUserInfo() {
		return userInfo;
	}

	public void setUserInfo(UserInfo userInfo) {
		this.userInfo = userInfo;
	}

	public String getActiveTab() {
		return activeTab;
	}

	public void setActiveTab(String activeTab) {
		this.activeTab = activeTab;
	}

	public AuthorityContext getAuthorityContext() {
		return authorityContext;
	}

	public void setAuthorityContext(AuthorityContext authorityContext) {
		this.authorityContext = authorityContext;
	}

}
