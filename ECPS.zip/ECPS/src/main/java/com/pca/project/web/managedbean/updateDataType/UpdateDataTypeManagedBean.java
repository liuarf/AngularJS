package com.pca.project.web.managedbean.updateDataType;

import java.net.InetAddress;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;

import com.pca.corefrmwk.context.AppContext;
import com.pca.corefrmwk.util.FacesUtils;
import com.pca.corefrmwk.util.MessageManager;
import com.pca.corefrmwk.web.managedbean.impl.TemplateDataTableManagedBean;
import com.pca.corefrmwk.web.session.content.UserInfo;
import com.pca.corefrmwk.web.vo.ValueObject;
import com.pca.corefrmwk.ws.AuditActionEmun;
import com.pca.corefrmwk.ws.AuditWSClient;
import com.pca.corefrmwk.ws.vo.AuditLogWSVO;
import com.pca.project.bo.UpdateDataType;
import com.pca.project.service.UpdateDataTypeService;
import com.pca.project.web.vo.UpdateDataTypeVo;
import com.pca.project.web.vowrapper.UpdateDataTypeVoWrapper;

@ManagedBean
@SessionScoped
public class UpdateDataTypeManagedBean
		extends
		TemplateDataTableManagedBean<UpdateDataType, java.lang.String, UpdateDataTypeService> {

	private static final long serialVersionUID = 1L;

	// 新增或修改狀態，新增為Create，修改為Update，用於detail時返回正確路徑用
	private String mode;

	// managedBean的主要使用service
	@ManagedProperty(value = "#{updateDataTypeService}")
	private UpdateDataTypeService service;
	// 登入使用者
	@ManagedProperty(value = "#{userInfo}")
	private UserInfo userInfo;
	//建立auditlog的client
	@ManagedProperty(value = "#{auditWSClient}")
	private AuditWSClient auditWSClient;
			
	@ManagedProperty(value = "#{appContext}")
	private AppContext appContext;	
	/**
	 * 建構子
	 */
	public UpdateDataTypeManagedBean() {

		super();

	}

	/**
	 * 初始設定
	 */
	@PostConstruct
	public void init() {
		// 設定是否一進頁面，即秀出資料
		this.setInitShowListData(true);
		// 初始話查詢條件
		this.initFindCriteriaMap();
		// 設定VoWrapper
		this.setVoWrapper(new UpdateDataTypeVoWrapper());

	}

	/**
	 * @return the mode
	 */
	public String getMode() {
		return mode;
	}

	/**
	 * @param mode
	 *            the mode to set
	 */
	public void setMode(String mode) {
		this.mode = mode;
	}

	/**
	 * 初始新增物件
	 * 
	 * @see com.pca.corefrmwk.web.managedbean.impl.BaseManagedBean#initCreatingData()
	 *
	 */
	@Override
	protected void initCreatingData() {
		UpdateDataType object = new UpdateDataType();

		this.setUpdatingData(this.wrap(object));

		this.setMode("Create");
	}

	/**
	 * 如需要再create or update按鈕按下後，對updating
	 * date進行處理，則需要撰寫此部分。但不管怎樣都需要override此method
	 * 
	 */
	@Override
	protected void initUpdatingData(
			ValueObject<UpdateDataType, java.lang.String> updatingData) {

		this.setMode("Update");
	}

	/**
	 * 在read頁面下，如有查詢輸入時，則續在建構子呼叫此函數來設定findCriteriaMap 如需要可斟酌修改
	 * 
	 * @see com.pca.corefrmwk.web.managedbean.impl.TemplateDataTableManagedBean#initFindCriteriaMap()
	 */
	@Override
	protected void initFindCriteriaMap() {
		// 目前只能先用String
		Map<String, Object> findCriteriaMap = new HashMap<String, Object>();

		findCriteriaMap.put("name", null);

		findCriteriaMap.put("code", null);

		this.setFindCriteriaMap(findCriteriaMap);
		// 設定操作
		Map<String, String> findOperMap = new HashMap<String, String>();

		findOperMap.put("name", "eq");
		findOperMap.put("code", "eq");

		this.setFindOperMap(findOperMap);

		// 設定排序
		Map<String, String> findSortMap = new HashMap<String, String>();

		findSortMap.put("name", "DESC");
		findSortMap.put("code", "DESC");

		this.setFindSortMap(findSortMap);
	}

	/**
	 * getUpdatingData 和 setUpdatingData 其實可以不需要, 因為 super class 已經有了 存在的目的,
	 * 只是為了讓 IDE 知道它的確切的type為何, 讓 jsf 的頁面比較好拖拉
	 * 
	 * @see com.pca.corefrmwk.web.managedbean.impl.BaseManagedBean#getUpdatingData()
	 *
	 */
	@Override
	public UpdateDataTypeVo getUpdatingData() {
		return (UpdateDataTypeVo) super.getUpdatingData();
	}

	/**
	 * 設定UpdatingData
	 * 
	 */
	@Override
	public void setUpdatingData(ValueObject<UpdateDataType, java.lang.String> vo) {
		super.setUpdatingData(vo);
	}

	/**
	 * 取得Service物件
	 */
	public UpdateDataTypeService getService() {

		return this.service;
	}

	/**
	 * 設定該ManagedBean的主要service
	 * 
	 * @param service
	 */
	public void setService(UpdateDataTypeService service) {
		this.service = service;
	}

	public UserInfo getUserInfo() {
		return userInfo;
	}

	public void setUserInfo(UserInfo userInfo) {
		this.userInfo = userInfo;
	}

	public AuditWSClient getAuditWSClient() {
		return auditWSClient;
	}

	public void setAuditWSClient(AuditWSClient auditWSClient) {
		this.auditWSClient = auditWSClient;
	}

	public AppContext getAppContext() {
		return appContext;
	}

	public void setAppContext(AppContext appContext) {
		this.appContext = appContext;
	}

	/**
	 * @see com.pca.corefrmwk.web.managedbean.impl.BaseManagedBean#setupUpdatingData()
	 */
	@Override
	protected void setupUpdatingData() {

	}

	/**
	 * 假如Entity(Business Object)，有Many-to-One或Many-to-Many的狀況， 則Code
	 * Generator會自動Override以供修改使用，可自行改成需要的Method，
	 * 主要作用是在read頁面就Fetch所有相關關聯的資料，免得再update頁面出現問題
	 * 
	 * @see com.pca.corefrmwk.web.managedbean.impl.TemplateDataTableManagedBean#findAllData()
	 */
	@Override
	protected List<UpdateDataType> findAllData() {
		return this.getService().findAllFetchRelation();
	}
	/**
	 * 因Audit需求，覆寫此方法
	 * @see com.pca.corefrmwk.web.managedbean.impl.TemplateDataTableManagedBean#doSaveCreateAction()
	 */
	@Override
	public String doSaveCreateAction() {
		try {

			//以下為建立audit log範例
			AuditLogWSVO auditLogWSVO = new AuditLogWSVO();
			auditLogWSVO.setSystemId(this.getAppContext().getSystemID());
			auditLogWSVO.setFunctionId("UpdateDataType");
			auditLogWSVO.setFunctionName("UpdateDataType");
			auditLogWSVO.setLoginId(this.getUserInfo().getUserId());
			auditLogWSVO.setAuditActionEmun(AuditActionEmun.Create_Process);
			//取得client IP
			String clientIp=FacesUtils.getClientIp();
			auditLogWSVO.setSourceIP(clientIp);
			//取得主機IP
			InetAddress addr;
			
			addr = InetAddress.getLocalHost();
			String  requestHostIP = addr.getHostAddress();
			auditLogWSVO.setRequestHostIP(requestHostIP);
			
			this.getAuditWSClient().createAuditLog(auditLogWSVO);
			//以上為建立audit log範例
			
			return super.doSaveCreateAction();

		} catch (Exception ex) {
			
			MessageManager.getInstance().processExceptionMessage(ex);
			return null;

		}
	}
	
	/**
	 * 因Audit需求，覆寫此方法
	 * @see com.pca.corefrmwk.web.managedbean.impl.TemplateDataTableManagedBean#doSaveUpdateAction()
	 */
	@Override
	public String doSaveUpdateAction() {
		try {
			

			//以下為建立audit log範例
			AuditLogWSVO auditLogWSVO = new AuditLogWSVO();
			auditLogWSVO.setSystemId(this.getAppContext().getSystemID());
			auditLogWSVO.setFunctionId("UpdateDataType");
			auditLogWSVO.setFunctionName("UpdateDataType");
			auditLogWSVO.setLoginId(this.getUserInfo().getUserId());
			auditLogWSVO.setAuditActionEmun(AuditActionEmun.Update_Process);
			//取得client IP
			String clientIp=FacesUtils.getClientIp();
			auditLogWSVO.setSourceIP(clientIp);
			//取得主機IP
			InetAddress addr;
			
			addr = InetAddress.getLocalHost();
			String  requestHostIP = addr.getHostAddress();
			auditLogWSVO.setRequestHostIP(requestHostIP);
			
			this.getAuditWSClient().createAuditLog(auditLogWSVO);
			//以上為建立audit log範例
			
			return super.doSaveUpdateAction();

		} catch (Exception ex) {
			MessageManager.getInstance().processExceptionMessage(ex);
			return null;

		}
	}
	
	/**
	 * 因Audit需求，覆寫此方法
	 * @see com.pca.corefrmwk.web.managedbean.impl.TemplateDataTableManagedBean#doDeleteOneAction()
	 */
	@Override
	public String doDeleteOneAction() {
		try {
			
			//以下為建立audit log範例
			AuditLogWSVO auditLogWSVO = new AuditLogWSVO();
			auditLogWSVO.setSystemId(this.getAppContext().getSystemID());
			auditLogWSVO.setFunctionId("UpdateDataType");
			auditLogWSVO.setFunctionName("UpdateDataType");
			auditLogWSVO.setLoginId(this.getUserInfo().getUserId());
			auditLogWSVO.setAuditActionEmun(AuditActionEmun.Delete_Process);
			//取得client IP
			String clientIp=FacesUtils.getClientIp();
			auditLogWSVO.setSourceIP(clientIp);
			//取得主機IP
			InetAddress addr;
			
			addr = InetAddress.getLocalHost();
			String  requestHostIP = addr.getHostAddress();
			auditLogWSVO.setRequestHostIP(requestHostIP);
			
			this.getAuditWSClient().createAuditLog(auditLogWSVO);
			//以上為建立audit log範例
			
			return super.doDeleteOneAction();
		} catch (Exception ex) {
			MessageManager.getInstance().processExceptionMessage(ex);
			return null;

		}
	}
	
	
	/**
	 * 因Audit需求，覆寫此方法
	 * @see com.pca.corefrmwk.web.managedbean.impl.TemplateDataTableManagedBean#doFindAction()
	 */
	@Override
    public String doFindAction() {
		try {
			
			//以下為建立audit log範例
			AuditLogWSVO auditLogWSVO = new AuditLogWSVO();
			auditLogWSVO.setSystemId(this.getAppContext().getSystemID());
			auditLogWSVO.setFunctionId("UpdateDataType");
			auditLogWSVO.setFunctionName("UpdateDataType");
			auditLogWSVO.setLoginId(this.getUserInfo().getUserId());
			auditLogWSVO.setAuditActionEmun(AuditActionEmun.Inquery_Process);
			//取得client IP
			String clientIp=FacesUtils.getClientIp();
			auditLogWSVO.setSourceIP(clientIp);
			//取得主機IP
			InetAddress addr;
			
			addr = InetAddress.getLocalHost();
			String  requestHostIP = addr.getHostAddress();
			auditLogWSVO.setRequestHostIP(requestHostIP);
			
			this.getAuditWSClient().createAuditLog(auditLogWSVO);
			//以上為建立audit log範例
			
			return super.doFindAction();
		} catch (Exception ex) {
			MessageManager.getInstance().processExceptionMessage(ex);
			return null;

		}
    }
}
