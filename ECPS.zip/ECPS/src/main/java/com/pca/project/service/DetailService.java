package com.pca.project.service;

import java.util.List;

import com.pca.corefrmwk.service.BaseService;
import com.pca.project.bo.Detail;

public interface DetailService extends BaseService<Detail, java.lang.String> {

	/**
	 * 假如Entity(Business Object)，有Many-to-One或Many-to-Many的狀況， 則Code
	 * Generator會產生此Interface以供修改使用，可自行改成需要的Method，
	 * 主要作用是在read頁面就Fetch所有相關關聯的資料，免得再update頁面出現問題
	 * 
	 * @return List<Detail>
	 */
	List<Detail> findAllFetchRelation();

}
