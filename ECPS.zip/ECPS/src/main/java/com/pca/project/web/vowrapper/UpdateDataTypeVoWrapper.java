package com.pca.project.web.vowrapper;

import com.pca.corefrmwk.web.vowrapper.impl.VoWrapperImpl;
import com.pca.project.bo.UpdateDataType;
import com.pca.project.web.vo.UpdateDataTypeVo;

/**
 * 轉換UpdateDataType為UpdateDataTypeVo的Wrapper
 * 
 */
public class UpdateDataTypeVoWrapper extends
		VoWrapperImpl<UpdateDataType, java.lang.String> {

	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	@Override
	public UpdateDataTypeVo wrap(UpdateDataType bo) {
		return new UpdateDataTypeVo(bo);
	}
}