package com.pca.project.web.vo;

import com.pca.corefrmwk.web.vo.impl.ValueObjectImpl;
import com.pca.project.bo.Detail;

/**
 * Detail's Value Object Implement
 * 
 */
public class DetailVo extends ValueObjectImpl<Detail, java.lang.String> {

	private static final long serialVersionUID = 1L;

	// Master的Id
	private String selectMasterId;

	/**
	 * Constructor
	 * 
	 */
	public DetailVo() {
		super(new Detail());
	}

	/**
	 * Constructor
	 * 
	 * @param bo
	 *            Business Object
	 */
	public DetailVo(Detail bo) {
		super(bo);
	}

	/**
	 * 回傳Detail Id p.s.由於單一Entity的Business Object可能會有父子層(Parent-Children)的連結狀況，
	 * Code Generator目前不會針對此部分自動產生出來，所以需要自行手動調整，相關命名方式可考
	 * 
	 * @return DetailId
	 */
	public String getSelectMasterId() {
		if (this.selectMasterId == null && this.getBo().getMaster() != null) {
			this.selectMasterId = this.getBo().getMaster().getId().toString();
		}
		return this.selectMasterId;

	}

	/**
	 * 設定Detail Id
	 * 
	 * @param selectDetailId
	 */
	public void setSelectMasterId(String selectMasterId) {

		this.selectMasterId = selectMasterId;
	}

}
