package com.pca.project.web.util;

/**
 * 用於下拉式選單的Factory，下面的code為參考用法， 但目前不建議使用，因為與session中的map綁訂
 * Current狀態下，可能會無法取到最新的值
 *
 */
public abstract class SelectFactory {

	public static SelectHelper createDepartmentSelect() {
		return new SelectHelper("department");
	}

	public static SelectHelper createGroupSelect() {
		return new SelectHelper("group");
	}

	public static SelectHelper createPositionSelect() {
		return new SelectHelper("position");
	}

	public static SelectHelper createUserSelect() {
		return new SelectHelper("user");
	}

}
