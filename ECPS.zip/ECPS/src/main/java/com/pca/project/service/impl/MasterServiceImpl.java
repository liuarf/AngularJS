package com.pca.project.service.impl;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pca.corefrmwk.service.impl.BaseServiceImpl;
import com.pca.project.bo.Master;
import com.pca.project.dao.MasterDao;
import com.pca.project.service.MasterService;

@Service("masterService")
public class MasterServiceImpl extends
		BaseServiceImpl<Master, java.lang.String, MasterDao> implements
		MasterService {

	@SuppressWarnings("unused")
	private final static Log LOG = LogFactory.getLog(MasterServiceImpl.class);

	@Autowired
	private MasterDao dao;

	/**
	 * 回傳Data Access Object
	 *
	 * @return masterDao
	 */
	public MasterDao getDao() {
		return this.dao;
	}

	/**
	 * 設定Data Access Object
	 *
	 * @param baseDao
	 */
	public void setDao(final MasterDao baseDao) {
		this.dao = baseDao;
	}

	/**
	 * 假如Entity(Business Object)，有Many-to-One或Many-to-Many的狀況， 則Code
	 * Generator會產生此Interface以供修改使用，可自行改成需要的Method，
	 * 主要作用是在read頁面就Fetch所有相關關聯的資料，免得再update頁面出現問題
	 * 
	 * @return List<Master>
	 */
	public List<Master> findAllFetchRelation() {

		return this.getDao().findAllFetchRelation();
	}

}