package com.pca.project.web.vo;

import com.pca.corefrmwk.web.vo.impl.ValueObjectImpl;
import com.pca.project.bo.UpdateDataType;

/**
 * UpdateDataType's Value Object Implement
 * 
 */
public class UpdateDataTypeVo extends
		ValueObjectImpl<UpdateDataType, java.lang.String> {

	private static final long serialVersionUID = 1L;

	/**
	 * Constructor
	 * 
	 */
	public UpdateDataTypeVo() {
		super(new UpdateDataType());
	}

	/**
	 * Constructor
	 * 
	 * @param bo
	 *            Business Object
	 */
	public UpdateDataTypeVo(UpdateDataType bo) {
		super(bo);
	}

}
