package com.pca.project.dao.jpa;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Service;

import com.pca.corefrmwk.persistence.dao.jpa.BaseDaoImpl;
import com.pca.project.bo.Master;
import com.pca.project.dao.MasterDao;

@Service("masterDao")
public class MasterDaoImpl extends BaseDaoImpl<Master, java.lang.String>
		implements MasterDao {

	@PersistenceContext(unitName = "persistenceUnit")
	private EntityManager entityManager;

	/**
	 * 取得EntityManager
	 * 
	 * @return
	 */
	public EntityManager getEntityManager() {
		return this.entityManager;
	}

	/**
	 * 設定EntityManager
	 * 
	 * @param entityManager
	 */
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	/**
	 * 假如Entity(Business Object)，有Many-to-One或Many-to-Many的狀況， 則Code
	 * Generator會產生此Interface以供修改使用，可自行改成需要的Method，
	 * 主要作用是在read頁面就Fetch所有相關關聯的資料，免得再update頁面出現問題 p.s.如有master
	 * detail的狀況請自行加入Fetch
	 * 
	 * @return List<Master>
	 */
	public List<Master> findAllFetchRelation() {
		StringBuffer queryString = new StringBuffer();
		queryString.append("SELECT DISTINCT obj FROM Master obj	");
		queryString.append("LEFT JOIN FETCH obj.details	");
		queryString.append("ORDER BY obj.id	");

		List<Master> list = this.find(queryString);

		return list;
	}
	
	@Override
	public List<Master> findByCriteriaMap(final Map<String, ? extends Object> criteriaMap, final Map<String, String> operMap, final Map<String, String> sortMap){
    	StringBuffer queryString = new StringBuffer();
        queryString.append("SELECT DISTINCT o FROM Master o ");
        queryString.append("LEFT JOIN FETCH o.details ");


        Map<String, Object> newCriteriaMap = new HashMap<String, Object>();

        // 用來判斷是否需要裁減String，因為條件句，最後可能是"AND"字串
        boolean isTruncateWhereQueryString = false;
        boolean isTruncateSortQueryString = false;
        for (String criteriaKey : criteriaMap.keySet()) {
            // 假如條件不為空則加入條件句
            if (null == criteriaMap.get(criteriaKey)) {
                continue;
            }
            if (criteriaMap.get(criteriaKey).toString().compareTo("") != 0) {
                if (!isTruncateWhereQueryString) {
                    queryString.append(" WHERE ");
                }
                if(operMap.get(criteriaKey.toString()).equals("eq")){
                    queryString.append("o.").append(criteriaKey.toString()).append(" = :").append(criteriaKey.toString().replace(".", "_"));
                }else if(operMap.get(criteriaKey.toString()).equals("ge")){
                    queryString.append("o.").append(criteriaKey.toString()).append(" >= :").append(criteriaKey.toString().replace(".", "_"));
                }else if(operMap.get(criteriaKey.toString()).equals("gt")){
                    queryString.append("o.").append(criteriaKey.toString()).append(" > :").append(criteriaKey.toString().replace(".", "_"));
                }else if(operMap.get(criteriaKey.toString()).equals("le")){
                    queryString.append("o.").append(criteriaKey.toString()).append(" <= :").append(criteriaKey.toString().replace(".", "_"));
                }else if(operMap.get(criteriaKey.toString()).equals("lt")){
                    queryString.append("o.").append(criteriaKey.toString()).append(" < :").append(criteriaKey.toString().replace(".", "_"));
                }else if(operMap.get(criteriaKey.toString()).equals("ne")){
                    queryString.append("o.").append(criteriaKey.toString()).append(" >< :").append(criteriaKey.toString().replace(".", "_"));
                }else if(operMap.get(criteriaKey.toString()).equals("like")){
                    queryString.append("o.").append(criteriaKey.toString()).append(" like :").append(criteriaKey.toString().replace(".", "_"));
                }else{                
                    queryString.append("o.").append(criteriaKey.toString()).append(" = :").append(criteriaKey.toString().replace(".", "_"));
                }
                queryString.append(" AND ");

                newCriteriaMap.put(criteriaKey.replace(".", "_"), criteriaMap.get(criteriaKey));
                isTruncateWhereQueryString = true;
            }
        }
        // 裁減queryString最尾端的"AND"字串
        if (isTruncateWhereQueryString) {
            int lastIndex = queryString.lastIndexOf("AND");
            queryString.delete(lastIndex, queryString.length());
        }
        //排序部分
        if (sortMap != null) {
            for (String sortKey : sortMap.keySet()) {
                // 假如條件不為空則加入條件句
                if (null == sortMap.get(sortKey)) {
                    continue;
                }
                if (sortMap.get(sortKey).toString().compareTo("") != 0) {
                    if (!isTruncateSortQueryString) {
                        queryString.append(" ORDER BY ");

                    }
                    queryString.append("o.").append(sortKey.toString()).append(" ").append(sortMap.get(sortKey));
                    queryString.append(" , ");


                    isTruncateSortQueryString = true;
                }
            }
            // 裁減queryString最尾端的","字串
            if (isTruncateSortQueryString) {
                int lastIndex = queryString.lastIndexOf(",");
                queryString.delete(lastIndex, queryString.length());
            }
        }
        return this.findByNamedParams(queryString, newCriteriaMap);
    }
}
