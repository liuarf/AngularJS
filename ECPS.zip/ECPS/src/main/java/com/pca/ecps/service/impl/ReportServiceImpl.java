package com.pca.ecps.service.impl;

import com.pca.ecps.service.ReportService;

public class ReportServiceImpl implements ReportService{

	public void genPdfToStream() throws Exception{}
}
