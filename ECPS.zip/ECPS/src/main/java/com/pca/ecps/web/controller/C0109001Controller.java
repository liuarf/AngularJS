package com.pca.ecps.web.controller;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.pca.corefrmwk.util.MessageManager;
import com.pca.ecps.to.C0109001To;
import com.pca.ecps.util.DateUtils;
import com.pca.ecps.util.ReportDownloader;
import com.pca.ecps.util.XmlUtils;
import com.pca.project.util.StringUtils;

@Controller
@RequestMapping("/pdf")
public class C0109001Controller implements Serializable {

	private static final long serialVersionUID = 7978442755539747571L;

	protected Logger logger = LoggerFactory.getLogger(this.getClass());
	
	private String getOutputFileName(){
		
		return "理賠保險金申請_"+DateUtils.getToDay()+".pdf";
	}
	
	/**
	 * 下載PDF
	 * @throws UnsupportedEncodingException 
	 */
	@RequestMapping(value = "/C0109001",method = RequestMethod.POST )
	public void doDownloadPdf(@RequestParam("reportData") String xml,HttpServletResponse response) throws UnsupportedEncodingException {
		
		logger.info("Arf debug - doDownloadPdf start...");
		
		ReportDownloader<C0109001To> downloader = new ReportDownloader<C0109001To>();
		Map<String, Object> globalParams = new HashMap<String, Object>();//未使用
		List<C0109001To> dataSource = new ArrayList<C0109001To>();
		String templateName = "/PdfTemplate/C0109001";

		logger.info("Arf debug - fPath=[" + templateName + "], getOutputFileName()=[" + getOutputFileName() + "]");
		try {
			C0109001To to = (C0109001To)XmlUtils.xmlStringToObject(xml, C0109001To.class);
			//logger.info("to=["+to.toString()+"]");
			dataSource.add(to);
			
			setGlobalParams(globalParams,to);
			
			ByteArrayOutputStream bos = downloader.genJReportToOutputStream(templateName, dataSource, globalParams);
			
			setResponseDataHeader(response,"application/pdf",getOutputFileName());
			
			bos.writeTo(response.getOutputStream());
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception :"+e.getMessage());
			MessageManager.getInstance().showWarnningMessage("下載 C0109001 發生錯誤");
		}
		logger.info("Arf debug - doDownloadPdf end...");
	}
	
	private void setResponseDataHeader(HttpServletResponse response,String contentType,String outputDilename) throws UnsupportedEncodingException{
		response.setContentType(contentType);
		response.setHeader("Content-Disposition",
				"attachment; filename=" + new String(outputDilename.getBytes("BIG5"), "ISO8859-1"));
	}
	
	private void setGlobalParams(Map<String, Object> globalParams,C0109001To to)throws JRException{
		
		try {
			String toDayStr = DateUtils.getToDay();
			to.setYearStr("" + (Integer.parseInt(toDayStr.substring(0,4))-1911) );
			to.setMonthStr(toDayStr.substring(4,6));
			to.setDateStr(toDayStr.substring(6));
			
			InputStream in = this.getClass().getResourceAsStream("/PdfTemplate/logo.png");
			globalParams.put("LogoImage", in);
		
			/*modify by Arf 2016/04/19 ，DocItem由原本的由前端網頁判斷，改為透過抓取申請項目(ApplyItem)自動判斷
			if (!StringUtils.isBlank(to.getDocItem())){//DocItem有值才處理
				String[] dpcItemArr = to.getDocItem().split(",");
				for(int ind=0 ;ind<dpcItemArr.length ; ind++ ){
					JasperDesign oJasperDesignSR = JRXmlLoader.load(this.getClass().getResourceAsStream("/PdfTemplate/C0109001Sub_"+dpcItemArr[ind]+".jrxml"));
					JasperReport oJasperReportSR = JasperCompileManager.compileReport(oJasperDesignSR);
		
					globalParams.put("DocItem_"+ind, oJasperReportSR);
				}
			}*/
			String dpcItemArr = to.getDocItemStr();//"XYYYYNNNNN";//
			
			int subInd=0;
			for(int ind=0 ;ind<dpcItemArr.length() ; ind++ ){
				if (dpcItemArr.charAt(ind)=='Y'){
					JasperDesign oJasperDesignSR = JRXmlLoader.load(this.getClass().getResourceAsStream("/PdfTemplate/C0109001Sub_"+ind+".jrxml"));
					JasperReport oJasperReportSR = JasperCompileManager.compileReport(oJasperDesignSR);
		
					globalParams.put("DocItem_"+subInd, oJasperReportSR);
					subInd++;
				}
			}
			
		} catch (JRException e) {
			//e.printStackTrace();
			logger.error("Exception:"+e.toString());
			throw e;
		}
		
	}
	
//	/**
//	 * Spring MVC Test
//	 * @throws UnsupportedEncodingException 
//	 */
//	@RequestMapping(value = "/test" )
//	public void doTest(@RequestParam("reportData") String xml) throws UnsupportedEncodingException {
//		
//		logger.info("Arf debug - doTest start...");
//		
//		logger.info("Arf debug - xml=["+xml+"]");
//		
//		logger.info("Arf debug - doTest end...");
//	}
}
