package com.pca.ecps.util;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.stream.StreamSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class XmlUtils {
	
	protected static Logger logger = LoggerFactory.getLogger(XmlUtils.class);
	
	public static Object xmlStringToObject(String xmlStr,Class className)throws Exception{
		try{
			logger.info("xmlStr=["+xmlStr+"]");
			logger.debug("className=["+className.getName()+"]");
			
			JAXBContext jc = JAXBContext.newInstance(className);
			
			Unmarshaller unmarshaller = jc.createUnmarshaller();
			
			StreamSource streamSource = new StreamSource(new StringReader(xmlStr));
			
			return unmarshaller.unmarshal(streamSource);
			
		}catch(Exception e){
			throw e;
		}
	}
}
