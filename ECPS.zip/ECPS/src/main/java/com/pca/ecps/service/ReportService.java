package com.pca.ecps.service;

public interface ReportService {

	public void genPdfToStream() throws Exception;
}
