package com.pca.ecps.util;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.util.FileResolver;
import net.sf.jasperreports.engine.xml.JRXmlLoader;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.pca.my_corefrmwk.report.jasper.Exporter;
import com.pca.my_corefrmwk.report.jasper.JasperRptLayoutTypeEnum;

public class ReportDownloader<T> {
	
	protected Logger logger = LoggerFactory.getLogger(this.getClass());
	
//	/**
//	 * 下載JsperReport
//	 * 
//	 * @param dataSource
//	 * @param globalParams
//	 * @param fileName
//	 * @param filePath
//	 * @throws Exception
//	 */
//	public void downloadJReport(final List<T> dataSource,
//			final Map<String, Object> globalParams, final String fileName,
//			final String filePath) throws Exception {
//
//		provideDownloadOutputStream(
//				genJReportToOutputStream(filePath, dataSource, globalParams),
//				fileName);
//
//	}

	/**
	 * PDF資料流
	 * 
	 * @param reportLayoutPath
	 * @param dataSource
	 * @param globalParams
	 * @return
	 * @throws Exception
	 */
	public ByteArrayOutputStream genJReportToOutputStream(
			String reportLayoutPath, List<T> dataSource,
			Map<String, Object> globalParams) throws Exception {
		logger.info("Arf debug - genJReportToOutputStream start...");
		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		InputStream reportStream =null;
		try{		
			Exporter exporter = new Exporter();
			// $F{}
			JRDataSource pJRptDS = new JRBeanCollectionDataSource(dataSource);
			// $P{}
			Map<String, Object> pParams = new HashMap<String, Object>(globalParams);
			
			String strFullRptName = reportLayoutPath+ JasperRptLayoutTypeEnum.JRXML.toString();
			
			reportStream = this.getClass().getResourceAsStream(strFullRptName);
			JasperDesign oJasperDesign = JRXmlLoader.load(reportStream);
			JasperReport oJasperReport = JasperCompileManager.compileReport(oJasperDesign);
			JasperPrint jasperPrint = JasperFillManager.fillReport(oJasperReport,pParams, pJRptDS);
			exporter.exportPDF(jasperPrint, byteArrayOutputStream);
		}catch(Exception e){
			logger.error("Exception :"+e.getMessage());
			throw e;
		}finally{
			if(reportStream!=null){
				reportStream.close();
			}
		}
		logger.info("Arf debug - genJReportToOutputStream end...");
		return byteArrayOutputStream;
	}
	
//	/**
//	 * 下載檔案
//	 * 
//	 * @param baos
//	 * @param fileName
//	 * @throws IOException
//	 */
//	public void provideDownloadOutputStream(final ByteArrayOutputStream baos,
//			final String fileName) throws IOException {
//		logger.info("Arf debug - provideDownloadOutputStream start..");
//		String contentType = "";
//		String type = fileName.split("\\.")[1];
//		FacesContext facesContext = FacesContext.getCurrentInstance();
//		ExternalContext externalContext = facesContext.getExternalContext();
//		if ("txt".equals(type)) {
//			contentType = "text/plain";
//		} else if ("xls".equals(type) || "xlsx".equals(type)) {
//			contentType = "vnd.ms-excel";
//		} else if ("pdf".equals(type)) {
//			contentType = "pdf";
//		}
//		externalContext.setResponseContentType("application/" + contentType);
//		externalContext.setResponseHeader("Content-Disposition",
//				"attachment; filename=" + new String(fileName.getBytes("BIG5"), "ISO8859-1"));
//
//		baos.writeTo(externalContext.getResponseOutputStream());
//		baos.flush();
//		baos.close();
//		facesContext.responseComplete();
//		
//		logger.info("Arf debug - provideDownloadOutputStream end..");
//	}
}
