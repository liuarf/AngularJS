package com.pca.ecps.to;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.commons.lang3.StringUtils;


/**
 * 
 * @author arf.cf.liu
 *
 */
@XmlRootElement(name="report")
@XmlAccessorType(XmlAccessType.FIELD)
public class C0109001To implements Serializable{

	private static final long serialVersionUID = 5857757983178956343L;
	private String reportType;		//reportType
	private String custName;		//姓名
	private String custIdNo;        //身分證字號
	private String birthday;        //出生日期
	private String applyType;       //申請險種
	private String applyItem;       //申請項目
	private String accidentTime;    //發生時間
	private String accidentLocation;//發生地點
	private String accidentReason;  //發生原因
	private String accidentDetail;  //意外事故發生經過
	
	private String agreedPay;		//支付方式確認選項
	//private String payData;         //支付方式
	private String insuranceTw;		//台幣保單
	private String transferName;	//匯款戶名
	private String transferType;	//匯款方式
	private String bankName;		//金融機構名稱
	private String payType;			//台幣付款方式
	private String transferAcct;	//台幣匯款帳號
	private String transferData;	//
	private String checkPayData;	//支票支付方式
	private String bankFlag = "Y";	//銀行/郵局
	private String insuranceFore;	//外幣保單
	private String foreTransferName;//英文戶名
	private String foreTransferAcct;//外幣匯款帳號
	private String foreTransferAddr;//英譯受款人地址
	private String foreBankName;	//英譯銀行名稱
	private String swiftCode;		//通匯代號
	private String foreBankAddr;	//英譯銀行地址
	private String foreTransferCountry;//受款人國籍
	
	private String declarationItem; //聲明事項
	private String declarationItem2;//聲明事項2
	private String tel;             //聯絡電話
	private String mobile;          //手機號碼
	private String address;         //聯絡地址
	private String email;           //E-Mail
	private String docItem;         //理賠申請應檢附文件
	
	private String otherStr;		//add by Arf 2016/05/25
	private String agentId;			//法定代理人身份證字號
	private String payMsg;			//給付方式訊息
	private String otherStr2;		//add by Arf 2016/07/18
	
	private String barcode;
	
	private String yearStr;
	private String monthStr;
	private String dateStr;
	
	public C0109001To() {
	}
	
	public C0109001To(String custName, String custIdNo, String birthday,
			String applyType, String applyItem, String accidentTime,
			String accidentLocation, String accidentReason,
			String accidentDetail, String payData, String bankName,
			String transferAcct, String checkPayData, String insuranceTw,
			String insuranceFore, String foreTransferName, String transferName,
			String transferType,
			String foreTransferAcct, String foreTransferAddr, String foreBankName,
			String swiftCode, String foreBankAddr, String foreTransferCountry,
			String declarationItem, String tel, String mobile, 
			String address, String email, String docItem,String agentId) {
		super();
		this.reportType = "C0109001";
		this.custName = custName;
		this.custIdNo = custIdNo;
		this.birthday = birthday;
		this.applyType = applyType;
		this.applyItem = applyItem;
		this.accidentTime = accidentTime;
		this.accidentLocation = accidentLocation;
		this.accidentReason = accidentReason;
		this.accidentDetail = accidentDetail;
		
		this.bankName = bankName;
		this.transferAcct = transferAcct;
		this.checkPayData = checkPayData;
		this.insuranceTw = insuranceTw;
		this.insuranceFore = insuranceFore;
		this.foreTransferName = foreTransferName;
		this.transferName = transferName;
		this.transferType = transferType;
		this.foreTransferAcct = foreTransferAcct;
		this.foreTransferAddr = foreTransferAddr;
		this.foreBankName = foreBankName;
		this.swiftCode = swiftCode;
		this.foreBankAddr = foreBankAddr;
		this.foreTransferCountry = foreTransferCountry;
		
		this.declarationItem = declarationItem;
		this.tel = tel;
		this.mobile = mobile;
		this.address = address;
		this.email = email;
		this.docItem = docItem;
		this.agentId = agentId;
	}
	
	public String getReportType() {
		return reportType;
	}

	public void setReportType(String reportType) {
		this.reportType = reportType;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getCustIdNo() {
		return custIdNo;
	}

	public void setCustIdNo(String custIdNo) {
		this.custIdNo = custIdNo;
	}

	public String getBirthday() {
		return birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public String getApplyType() {
		return applyType;
	}

	public void setApplyType(String applyType) {
		this.applyType = applyType;
	}

	public String getApplyItem() {
		return applyItem;
	}

	public void setApplyItem(String applyItem) {
		this.applyItem = applyItem;
	}

	public String getAccidentTime() {
		return accidentTime;
	}

	public void setAccidentTime(String accidentTime) {
		this.accidentTime = accidentTime;
	}

	public String getAccidentLocation() {
		return accidentLocation;
	}

	public void setAccidentLocation(String accidentLocation) {
		this.accidentLocation = accidentLocation;
	}

	public String getAccidentReason() {
		return accidentReason;
	}

	public void setAccidentReason(String accidentReason) {
		this.accidentReason = accidentReason;
	}

	public String getAccidentDetail() {
		return accidentDetail;
	}

	public void setAccidentDetail(String accidentDetail) {
		this.accidentDetail = accidentDetail;
	}

	public String getInsuranceTw() {
		return insuranceTw;
	}

	public void setInsuranceTw(String insuranceTw) {
		this.insuranceTw = insuranceTw;
	}

	public String getTransferName() {
		if (StringUtils.isBlank(transferName)){
			return transferName;
		}else{
			return "戶名："+transferName;
		}
	}

	public void setTransferName(String transferName) {
		this.transferName = transferName;
	}

	public String getBankName() {
		if (StringUtils.isBlank(bankName)){
			return bankName;
		}else{
			if (bankFlag.equalsIgnoreCase("Y")){
				return "金融機構："+bankName;
			}else{
				//return "局號："+bankName + " 帳號：" +transferAcct;
				return "局號："+bankName ;
			}
		}
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getTransferAcct() {
		if (StringUtils.isBlank(transferAcct)){
			return transferAcct;
		}else{
			//if (bankFlag.equalsIgnoreCase("Y")){
				return "帳號："+transferAcct;
			/*}else{
				return "";
			}*/
		}
	}

	public void setTransferAcct(String transferAcct) {
		this.transferAcct = transferAcct;
	}

	public String getCheckPayData() {
		return checkPayData;
	}

	public void setCheckPayData(String checkPayData) {
		this.checkPayData = checkPayData;
	}

	public String getInsuranceFore() {
		return insuranceFore;
	}

	public void setInsuranceFore(String insuranceFore) {
		this.insuranceFore = insuranceFore;
	}

	public String getForeTransferName() {
		if (StringUtils.isBlank(foreTransferName)){
			return foreTransferName;
		}else{
			return "英文戶名：" + foreTransferName;
		}
	}

	public void setForeTransferName(String foreTransferName) {
		this.foreTransferName = foreTransferName;
	}

	public String getForeTransferAcct() {
		if (StringUtils.isBlank(foreTransferAcct)){
			return foreTransferAcct;
		}else{
			return "帳號：" + foreTransferAcct;
		}
	}

	public void setForeTransferAcct(String foreTransferAcct) {
		this.foreTransferAcct = foreTransferAcct;
	}

	public String getForeTransferAddr() {
		if ( (!isOIU()) || (StringUtils.isBlank(foreTransferAddr)) ){
			return "";//foreTransferAddr;
		}else{
			return "英譯受款人地址：" + foreTransferAddr;
		}
	}

	public void setForeTransferAddr(String foreTransferAddr) {
		this.foreTransferAddr = foreTransferAddr;
	}

	public String getForeBankName() {
		if (StringUtils.isBlank(foreBankName)){
			return foreBankName;
		}else{
			return "英譯銀行名稱：" + foreBankName;
		}
	}

	public void setForeBankName(String foreBankName) {
		this.foreBankName = foreBankName;
	}

	public String getSwiftCode() {
		if (StringUtils.isBlank(swiftCode)){
			return swiftCode;
		}else{
			return "通匯代號(SWIFT Code)：" + swiftCode;
		}
	}

	public void setSwiftCode(String swiftCode) {
		this.swiftCode = swiftCode;
	}

	public String getForeBankAddr() {
		if (StringUtils.isBlank(foreBankAddr)){
			return foreBankAddr;
		}else{
			return "英譯銀行地址：" + foreBankAddr;
		}
	}

	public void setForeBankAddr(String foreBankAddr) {
		this.foreBankAddr = foreBankAddr;
	}

	public String getForeTransferCountry() {
		if ( (!isOIU()) || (StringUtils.isBlank(foreTransferCountry)) ){
			return "";//foreTransferCountry;
		}else{
			return "受款人國籍：" + foreTransferCountry;
		}
	}

	public void setForeTransferCountry(String foreTransferCountry) {
		this.foreTransferCountry = foreTransferCountry;
	}

	public String getDeclarationItem() {
		return declarationItem;
	}

	public void setDeclarationItem(String declarationItem) {
		this.declarationItem = declarationItem;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmail() {
		if ((!isOIU()) || (StringUtils.isBlank(email))){
			return "";//email;
		}else{
			return "E-mail：" + email;
		}
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDocItem() {
		return docItem.trim();
	}

	public void setDocItem(String docItem) {
		this.docItem = docItem;
	}

	public String getAgreedPay() {
		return agreedPay;
	}

	public void setAgreedPay(String agreedPay) {
		this.agreedPay = agreedPay;
	}

	public String getDeclarationItem2() {
		return declarationItem2;
	}

	public void setDeclarationItem2(String declarationItem2) {
		this.declarationItem2 = declarationItem2;
	}
	
	/**
	 * add by Arf 2016/04/19 透過ApplyItem自動判斷該顯示那些檢附文件區塊
	 * @return
	 */
	public String getDocItemStr(){
		char[] ret = {'X','N','N','N','N','N','N','N','N','N'};
		
		if (getApplyItem().indexOf("醫療") != -1){
			ret[5]='Y';
			ret[6]='Y';
		}
		if (getApplyItem().indexOf("殘廢") != -1){
			ret[3]='Y';
			ret[4]='Y';
		}
		if (getApplyItem().indexOf("身故") != -1){
			ret[1]='Y';
			ret[2]='Y';
		}
		if (getApplyItem().indexOf("重大") != -1){
			ret[7]='Y';
		}
		return new String(ret);
	}

	public String getBankFlag() {
		return bankFlag;
	}

	public void setBankFlag(String bankFlag) {
		this.bankFlag = bankFlag;
	}

	public String getAgentId() {
		return agentId;
	}

	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}

	public String getPayMsg() {
		if ((StringUtils.isBlank(checkPayData)) || ("Y".equalsIgnoreCase(insuranceFore))){
			return "※下述帳戶確為本人所有，嗣後若有因資料錯誤而造成誤匯/退匯時，概由本人自行負責。";
		}else{
			return "";
		}
	}

	public void setPayMsg(String payMsg) {
		this.payMsg = payMsg;
	}

	public String getBarcode() {
		
		if (getApplyItem().indexOf("身故") != -1){//身故
			return "*C0101201*";
		}else{
			return "*C0101101*";
		}
	}

	public void setBarcode(String barcode) {
		this.barcode = barcode;
	}
	
	private boolean isOIU(){
		if (getApplyType().indexOf("OIU") != -1){
			return true;
		}else{
			return false;
		}
	}
	
	public String getOtherStr() {
		if ((getApplyItem().indexOf("其他") != -1) && (getDocItemStr().indexOf("Y")!=-1)){
			return "「理賠保險金申請書」、「診斷證明書正本或副本」(若本公司審核需要其他相關證明文件時，將再另行通知)";
		}else{
			return "";
		}
	}

	public void setOtherStr(String otherStr) {
		this.otherStr = otherStr;
	}

	public String getOtherStr2() {
		if (getDocItemStr().indexOf("Y")==-1){
			return "「理賠保險金申請書」、「診斷證明書正本或副本」(若本公司審核需要其他相關證明文件時，將再另行通知)";
		}else{
			return "";
		}
	}

	public void setOtherStr2(String otherStr2) {
		this.otherStr2 = otherStr2;
	}

	public String getPayType() {
		
		if (StringUtils.isBlank(this.getCheckPayData())){
			return "給付方式：匯款";
		}else{
			return "給付方式：支票";
		}
	}

	public void setPayType(String payType) {
		this.payType = payType;
	}

	public String getTransferData() {
		return transferData;
	}

	public void setTransferData(String transferData) {
		this.transferData = transferData;
	}

	public String getTransferType() {
		return transferType;
	}

	public void setTransferType(String transferType) {
		this.transferType = transferType;
	}

	public String getYearStr() {
		return yearStr;
	}

	public void setYearStr(String yearStr) {
		this.yearStr = yearStr;
	}

	public String getMonthStr() {
		return monthStr;
	}

	public void setMonthStr(String monthStr) {
		this.monthStr = monthStr;
	}

	public String getDateStr() {
		return dateStr;
	}

	public void setDateStr(String dateStr) {
		this.dateStr = dateStr;
	}
	

//	@Override
//	public String toString() {
//		return "C0109001To [reportType=" + reportType + ", custName="
//				+ custName + ", custIdNo=" + custIdNo + ", birthday="
//				+ birthday + ", applyType=" + applyType + ", applyItem="
//				+ applyItem + ", accidentTime=" + accidentTime
//				+ ", accidentLocation=" + accidentLocation
//				+ ", accidentReason=" + accidentReason + ", accidentDetail="
//				+ accidentDetail + ", agreedPay=" + agreedPay
//				+ ", insuranceTw=" + insuranceTw + ", transferName="
//				+ transferName + ", bankName=" + bankName + ", transferAcct="
//				+ transferAcct + ", checkPayData=" + checkPayData
//				+ ", insuranceFore=" + insuranceFore + ", foreTransferName="
//				+ foreTransferName + ", foreTransferAcct=" + foreTransferAcct
//				+ ", foreTransferAddr=" + foreTransferAddr + ", foreBankName="
//				+ foreBankName + ", swiftCode=" + swiftCode + ", foreBankAddr="
//				+ foreBankAddr + ", foreTransferCountry=" + foreTransferCountry
//				+ ", declarationItem=" + declarationItem
//				+ ", declarationItem2=" + declarationItem2 + ", tel=" + tel
//				+ ", mobile=" + mobile + ", address=" + address + ", email="
//				+ email + ", docItem=" + docItem + "]";
//	}
	
}

