package com.pca.ecps.util;

import java.util.Calendar;

public class DateUtils extends com.pca.project.util.DateUtils{

	public static String getToDay(){
		Calendar cd = Calendar.getInstance();
		
		return DateUtils.getSimpleISODateStr(cd.getTime());
	}
}
