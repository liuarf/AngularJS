package com.pca.ecps.util;

public enum ReportType {

	C0109001("C0109001","C0109001To",""),
	C0109002("C0109002","C0109002To","");
	
	private String typeName;
	private String toClassName;
	private String desc;
	
	private ReportType(String typeName,String toClassName,String desc){
		this.typeName = typeName;
		this.toClassName = toClassName;
		this.desc = desc;
	}

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	public String getToClassName() {
		return toClassName;
	}

	public void setToClassName(String toClassName) {
		this.toClassName = toClassName;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	/*
	public static Class getToClass(String typeName){
		for(ReportType type : ReportType.values()){
			if (type.getTypeName().equals(typeName)){
				return Class.forName(type.getToClassName());
			}
		}
		return null;
	}
	*/
}
