package com.pca.my_corefrmwk.report.jasper;

import java.io.ByteArrayOutputStream;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.export.JRHtmlExporter;
import net.sf.jasperreports.engine.export.JRHtmlExporterParameter;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.engine.export.JRXlsAbstractExporterParameter;
import net.sf.jasperreports.engine.export.JRXlsExporter;

/**
 * Everything under the package org.krams.tutorial.jasper are settings imposed
 * by Jasper (not DynamicJasper)
 * <p>
 * An exporter for exporting the report in various formats, i.e Excel, PDF, CSV.
 * Here we declare a PDF exporter
 */
public class Exporter {

	/**
	 * Exports a report to XLS (Excel) format. You can declare another export
	 * here, i.e PDF or CSV. You don't really need to create a separate class or
	 * method for the exporter. You can call it directly within your Service or
	 * Controller.
	 * 
	 * @param jp
	 *            the JasperPrint object
	 * @param baos
	 *            the ByteArrayOutputStream where the report will be written
	 */
	public void export(JasperPrint jp, ByteArrayOutputStream baos)
			throws JRException {
		// Create a JRXlsExporter instance
		JRXlsExporter exporter = new JRXlsExporter();

		// Here we assign the parameters jp and baos to the exporter
		exporter.setParameter(JRExporterParameter.JASPER_PRINT, jp);
		exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, baos);

		// Excel specific parameters
		// Check the Jasper (not DynamicJasper) docs for a description of these
		// settings. Most are
		// self-documenting
		exporter.setParameter(
				JRXlsAbstractExporterParameter.IS_ONE_PAGE_PER_SHEET,
				Boolean.FALSE);
		exporter.setParameter(
				JRXlsAbstractExporterParameter.IS_REMOVE_EMPTY_SPACE_BETWEEN_ROWS,
				Boolean.TRUE);
		exporter.setParameter(
				JRXlsAbstractExporterParameter.IS_WHITE_PAGE_BACKGROUND,
				Boolean.FALSE);

		// Retrieve the exported report in XLS format
		exporter.exportReport();
	}

	public void exportPDF(JasperPrint jp, ByteArrayOutputStream baos)
			throws JRException {
		// Create a JRXlsExporter instance
		JRPdfExporter exporter = new JRPdfExporter();

		// Here we assign the parameters jp and baos to the exporter
		exporter.setParameter(JRExporterParameter.JASPER_PRINT, jp);
		exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, baos);

		// Retrieve the exported report in PDF format
		exporter.exportReport();
	}

	public void exportHTML(JasperPrint jp, ByteArrayOutputStream baos)
			throws JRException {
		// Create a JRXlsExporter instance
		// 使用 JRHtmlExporter 来生成 html , 很多参数可以查 api 或 ireport 的属性窗口
		// JRExporter htmlExporter = new JRHtmlExporter();
		JRHtmlExporter jrHtmlExporter = new JRHtmlExporter();

		// Here we assign the parameters jp and baos to the exporter
		// exporter.setParameter(JRExporterParameter.JASPER_PRINT, jp);
		// exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, baos);

		jrHtmlExporter.setParameter(JRHtmlExporterParameter.JASPER_PRINT, jp);
		jrHtmlExporter.setParameter(
				JRHtmlExporterParameter.IS_USING_IMAGES_TO_ALIGN, true);
		// To generate a HTML report we want configure ImageServlet in
		// component.xml file of reporting UI bundle
		// Then want to set the IMAGES_URI parameter
		// jrHtmlExporter.setParameter(JRHtmlExporterParameter.IMAGES_URI,
		// "../servlets/image?image=");
		// remove empty spaces
		jrHtmlExporter.setParameter(
				JRHtmlExporterParameter.IS_REMOVE_EMPTY_SPACE_BETWEEN_ROWS,
				Boolean.TRUE);
		jrHtmlExporter.setParameter(
				JRHtmlExporterParameter.IS_WHITE_PAGE_BACKGROUND, Boolean.TRUE);
		jrHtmlExporter
				.setParameter(JRHtmlExporterParameter.OUTPUT_STREAM, baos);
		jrHtmlExporter.exportReport();

		// Retrieve the exported report in HTML format
		jrHtmlExporter.exportReport();
	}

	/*
	 * if(exporter == null) { if (format.equalsIgnoreCase("csv")) exporter = new
	 * JRCsvExporter(); else if (format.equalsIgnoreCase("html")) exporter = new
	 * JRHtmlExporter(); else if (format.equalsIgnoreCase("xls")) exporter = new
	 * JExcelApiExporter(); //exporter = new JRXlsExporter(); else if
	 * (format.equalsIgnoreCase("rtf")) exporter = new JRRtfExporter(); else if
	 * (format.equalsIgnoreCase("xml")) exporter = new JRXmlExporter(); else if
	 * (format.equalsIgnoreCase("txt")) exporter = new JRTextExporter(); else if
	 * (format.equalsIgnoreCase("pdf")) exporter = new JRPdfExporter(); else if
	 * (format.equalsIgnoreCase("JPG"))exporter = new JRJpegExporter(); else if
	 * (format.equalsIgnoreCase("JPGBASE64"))exporter = new
	 * JRImageBase64Exporter(); else exporter = new JRHtmlExporter(); }
	 */
}
