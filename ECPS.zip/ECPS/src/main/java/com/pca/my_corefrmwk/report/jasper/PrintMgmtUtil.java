package com.pca.my_corefrmwk.report.jasper;

import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.pca.corefrmwk.report.jasper.PrintManager;
import com.pca.corefrmwk.report.jasper.datasource.ListDataSource;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;

// import com.lowagie.text.pdf.codec.Base64.InputStream;

/*
 *  Maintain History:
 *
 *         Author       Date         PIS/SR NO.       Comment
 *         ==========   ===========  ===========   ==========================
 *         Charlotte    2013/01/11    SR-28419      Initial version
 * 
 */
public class PrintMgmtUtil extends PrintManager {
	// public class PrintMgmtUtil {

	/**
	 * Load JasperReport layout file 載入 JasperReport 報表設計檔案, 例: Report.jrxml or
	 * Report.jasper
	 * 
	 * @param pReportFullName
	 *            Jasper report 報表設計檔案名稱, 必須含自[class] folder 開始存放的相對路徑(eg: 傳入
	 *            "/tree-template", 表放於 [/WEB-INF/classes/] folder
	 * @param pJRptType
	 *            Jasper report 報表設計檔案形態(.jrxml or .jasper)
	 * @return JasperReport instance
	 * @throws Exception
	 */
	public JasperReport loadReportLayout(String pReportFullName,
			JasperRptLayoutTypeEnum pJRptType) throws Exception {
		// InputStream oInputStream;
		JasperDesign oJasperDesign;
		JasperReport oJasperReport = null;
		String strFullRptName = null;

		strFullRptName = pReportFullName
				+ JasperRptLayoutTypeEnum.JRXML.toString();

		// 新的方法 compile after loading .jrxml
		if (pJRptType == JasperRptLayoutTypeEnum.JRXML) {
			// Retrieve our report template
			// InputStream reportStream =
			// this.getClass().getResourceAsStream(getTemplateDirectory() +
			// pReportName
			// + JasperRptLayoutTypeEnum.JRXML.toString());
			// strFullRptName = pReportFullName +
			// JasperRptLayoutTypeEnum.JRXML.toString();
			// InputStream reportStream =
			// this.getClass().getResourceAsStream(pReportName +
			// JasperRptLayoutTypeEnum.JRXML.toString());
			InputStream reportStream = this.getClass().getResourceAsStream(
					strFullRptName);

			// Create a JasperDesign object from the JRXMl file
			oJasperDesign = JRXmlLoader.load(reportStream);
			// Compile our report layout
			oJasperReport = JasperCompileManager.compileReport(oJasperDesign);
		} // if (jRptType == JasperRptTypeEnum.JRXML) {

		// 以下是舊的load .jasper
		/*
		 * 待測試 if (pJRptType == JasperRptLayoutTypeEnum.JASPER) { //String
		 * strTmp = new String(
		 * "D:\\Charlotte\\DVP_Env\\Eclipse_DVP\\workspace_42\\PCALT_TestPrj_1\\jasperTemplates\\report1.jasper"
		 * ); //getTemplateDirectory() + pReportName +
		 * JasperRptLayoutTypeEnum.JASPER.toString(); //File oReportFile1 = new
		 * File(strTmp); File oReportFile1 = new File(getTemplateDirectory() +
		 * pReportFullName + JasperRptLayoutTypeEnum.JASPER.toString());
		 * oJasperReport = (JasperReport) JRLoader.loadObject(oReportFile1); }
		 * // if (jRptType == JasperRptTypeEnum.JRXML) {
		 */

		return oJasperReport;
	} // public JasperReport loadReportLayout(String reportName,
		// JasperRptTypeEnum jRptType) throws Exception {

	/**
	 * Prepare the Print Instance of JasperReport *
	 * 
	 * @param pReport
	 *            報表設計檔(JasperReport instance)
	 * @param pReportName
	 *            報表設計檔
	 * @param pRecords
	 *            產生報表資料List
	 * @param pParams
	 *            產生報表參數
	 * @return JasperReport Print instance
	 * @throws Exception
	 */
	public JasperPrint prepareJRptPrint(JasperReport pReport,
			List<Object> pRecords, Map<String, Object> pParams)
			throws Exception {
		JRDataSource oJRDataSource;
		JasperPrint oJasperPrint;

		if (pRecords == null) {
			pRecords = new ArrayList<Object>();
			pRecords.add(new Object());
		}
		oJRDataSource = new ListDataSource(pRecords);

		oJasperPrint = JasperFillManager.fillReport(pReport, pParams,
				oJRDataSource);

		return oJasperPrint;
	} // public JasperPrint prepareJRptPrint(JasperReport pReport, List
		// pRecords, Map pParams) throws Exception {

	/**
	 * 列印PDF報表
	 * 
	 * @param pReportLayoutName
	 *            報表名稱，即Jasper Layout的檔名，不包含副檔名。
	 * @param pJRptLayoutType
	 *            Jasper Layout 報表設計檔格式
	 * @param records
	 *            顯示多筆明細部份的資料。即報表內 $F{}的資料。
	 * @param pParams
	 *            即報表內$P{}的資料。
	 * @param extendedPath
	 *            如果為null ，會依照AppContext
	 *            所設定的"app root + 系統預設的報表產出路徑"為主，請看applicationContext
	 *            .xml；如果不為null，會以"app root + 自行輸入的extendedPat"為報表產出路徑。
	 * @param pOutputFileName
	 *            產出的PDF檔名。可加.pdf或不加副檔名，function會自動判斷。
	 * @throws Exception
	 *             任何報表產生失敗的錯誤。
	 */
	public void printJReportToPdfFormat(String pReportLayoutName,
			JasperRptLayoutTypeEnum pJRptLayoutType, List<Object> pRecords,
			Map<String, Object> pParams, String extendedPath,
			String pOutputFileName) throws Exception {
		JasperReport oJasperReport = null;
		JasperPrint oJasperPrint = null;
		String strOutputFileName = null;
		String strOutputFileDir = null;

		strOutputFileDir = makeResultDir(extendedPath);
		oJasperReport = loadReportLayout(pReportLayoutName, pJRptLayoutType);
		oJasperPrint = prepareJRptPrint(oJasperReport, pRecords, pParams);

		// strOutputFileName = pOutputFileName + FileTypeEnum.PDF.toString();
		strOutputFileName = testToAddExtension(pOutputFileName,
				FileTypeEnum.PDF.toString());
		// printJReportToPdfFormat(oJasperPrint, strOutputFileName);
		printJReportToPdfFormat(oJasperPrint, strOutputFileDir
				+ strOutputFileName);
	} // public void printJReportToPdfFormat(...)

	public void printJReportToPdfFormat(JasperPrint pJasperPrint,
			String pOutputFileName) throws Exception {

		beforeFlushing(pJasperPrint, 0);
		JasperExportManager
				.exportReportToPdfFile(pJasperPrint, pOutputFileName);
	} // public void printJReportToPdfFormat(JasperPrint pJasperPrint, String
		// pOutputFileName) throws Exception {

	/**
	 * 用以產生報表
	 * 
	 * @param pReportLayoutName
	 *            報表名稱，即Jasper Layout的檔名，不包含副檔名。
	 * @param pJRptLayoutType
	 *            Jasper Layout 報表設計檔格式
	 * @param pJRptDS
	 *            (JRDataSource) 顯示多筆明細部份的資料。即報表內 $F{}的資料。
	 * @param pParams
	 *            即報表內$P{}的資料。
	 * @param extendedPath
	 *            如果為null ，會依照AppContext
	 *            所設定的"app root + 系統預設的報表產出路徑"為主，請看applicationContext
	 *            .xml；如果不為null，會以"app root + 自行輸入的extendedPat"為報表產出路徑。
	 * @param pOutputFileName
	 *            產出的PDF檔名。可加.pdf或不加副檔名，function會自動判斷。
	 * @throws Exception
	 *             任何報表產生失敗的錯誤。
	 */
	public JasperPrint genJReportToOutputStream(String pReportLayoutName,
			JasperRptLayoutTypeEnum pJRptLayoutType, JRDataSource pJRptDS,
			Map<String, Object> pParams, String extendedPath,
			String pOutputFileName) throws Exception {

		JasperReport oJasperReport = null;
		JasperPrint oJasperPrint = null;
		// String strOutputFileName = null;
		// String strOutputFileDir = null;

		// try {
		// } catch (e )
		// strOutputFileDir = makeResultDir(extendedPath);
		oJasperReport = loadReportLayout(pReportLayoutName, pJRptLayoutType);
		// oJasperPrint = prepareJRptPrint(oJasperReport, pJRptDS, pParams);
		oJasperPrint = JasperFillManager.fillReport(oJasperReport, pParams,
				pJRptDS);

		return oJasperPrint;
	} // public void printJReportToPdfFormat(JasperPrint pJasperPrint, String
		// pOutputFileName) throws Exception {

	/**
	 * 用以產生報表, overload: genJReportToOutputStream(..)
	 * 
	 * @param pJRptLayoutType
	 *            Jasper Layout 報表設計檔格式 (String type)
	 * @see genJReportToOutputStream(String pReportLayoutName,
	 *      JasperRptLayoutTypeEnum pJRptLayoutType, JRDataSource pJRptDS,
	 *      Map<String, Object> pParams, String extendedPath, String
	 *      pOutputFileName)
	 */
	public JasperPrint genJReportToOutputStream(String pReportLayoutName,
			String pJRptLayoutType, JRDataSource pJRptDS,
			Map<String, Object> pParams, String extendedPath,
			String pOutputFileName) throws Exception {
		JasperPrint oJasperPrint = null;
		JasperRptLayoutTypeEnum oJRptLayoutType = null;

		if (pJRptLayoutType.equals(JasperRptLayoutTypeEnum.JRXML.toString())) {
			oJRptLayoutType = JasperRptLayoutTypeEnum.JRXML;
		} else {
			oJRptLayoutType = JasperRptLayoutTypeEnum.JASPER;
		}

		oJasperPrint = genJReportToOutputStream(pReportLayoutName,
				oJRptLayoutType, pJRptDS, pParams, extendedPath,
				pOutputFileName);

		return oJasperPrint;
	}

	// Remove this when merge to CoreFramework Lib.
	private String makeResultDir(String extendedPath) {

		String resultDir;
		if (extendedPath != null) {
			if (!extendedPath.startsWith("/"))
				extendedPath = "/" + extendedPath;
			resultDir = getAppContext().getAppRoot() + extendedPath;
		} else
			resultDir = getOutputDirectory();

		new File(resultDir).mkdirs();

		return resultDir;
	}

	// Remove this when merge to CoreFramework Lib.
	private String testToAddExtension(String fileName, String fileExtension) {

		if (!fileName.endsWith(fileExtension))
			fileName = fileName + fileExtension;

		return fileName;
	}

}
