package com.pca.my_corefrmwk.report.jasper;

/**
 * 檔案列舉形態
 * 
 * @author charlotte.lp.liu
 * @version 1.0
 * @created 21-十二月-2012 下午 10:13:00
 */
public enum JasperRptLayoutTypeEnum {
	JRXML {
		public String toString() {
			return ".jrxml";
		}
	},
	JASPER {
		public String toString() {
			return ".jasper";
		}
	}
}
