package com.pca.my_corefrmwk.report.jasper;

/**
 * 檔案列舉形態
 * 
 * @author charlotte.lp.liu
 * @version 1.0
 * @created 18-十二月-2012 下午 05:40:59
 */
public enum FileTypeEnum {
	CSV {
		public String toString() {
			return ".csv";
		}
	},
	EXCEL {
		public String toString() {
			return ".xls";
		}
	},
	PDF {
		public String toString() {
			return ".pdf";
		}
	},
	HTML {
		public String toString() {
			return ".html";
		}
	},
	RTF {
		public String toString() {
			return ".rtf";
		}
	},
	WORD {
		public String toString() {
			return ".doc";
		}
	},
	JASPERRPT {
		public String toString() {
			return ".jasperrpt";
		}
	};

	public static FileTypeEnum conversionToEnum(String pFileType)
			throws Exception {
		for (FileTypeEnum currentType : FileTypeEnum.values()) {
			if (pFileType.equals(currentType.toString())) {
				return currentType;
			}
		}
		// return FileTypeEnum.PDF; // Default Value
		throw new Exception("Unmatched Type");
	}

	/*
	 * public static FileTypeEnum conversionToEnum(String s){ FileTypeEnum
	 * fteFileType = FileTypeEnum.PDF;
	 * 
	 * if(s != null){ if (s.equalsIgnoreCase(".csv")) { fteFileType =
	 * FileTypeEnum.CSV; } if (s.equalsIgnoreCase(".xls")) { fteFileType =
	 * FileTypeEnum.EXCEL; } if (s.equalsIgnoreCase(".html") ||
	 * s.equalsIgnoreCase(".htm")) { fteFileType = FileTypeEnum.HTML; } if
	 * (s.equalsIgnoreCase(".rtf")) { fteFileType = FileTypeEnum.RTF; } } return
	 * fteFileType; }
	 */
}
