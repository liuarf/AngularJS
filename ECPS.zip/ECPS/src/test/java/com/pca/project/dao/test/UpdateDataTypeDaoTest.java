package com.pca.project.dao.test;

import java.util.HashMap;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import com.pca.project.bo.UpdateDataType;
import com.pca.project.dao.UpdateDataTypeDao;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({ "classpath*:**/test/conf/spring/ApplicationContext.xml" })
@Transactional("transactionManager400")
@TransactionConfiguration(defaultRollback = true)
public class UpdateDataTypeDaoTest {

	@Autowired
	UpdateDataTypeDao dao;

	@Test
	public void testCreate() {
		UpdateDataType testingObj = new UpdateDataType();

		// TODO Input PK
		testingObj.setId("Input pk");
		dao.create(testingObj);

		Assert.assertNotEquals(testingObj.getId(), null);
	}

	@Test
	public void testRead() {

		UpdateDataType testingObj = dao.findByPK("Input pk");

		Assert.assertEquals(testingObj.getId(), "Input pk");
	}

	@Test
	public void testUpdate() {
		// TODO update at least a field
		UpdateDataType testingObj = dao.findByPK("Input pk");
		testingObj.setName("test2");
		dao.update(testingObj);

		Assert.assertEquals(testingObj.getName(), "test2");
	}

	@Test
	public void testDelete() {
		// TODO Input PK
		UpdateDataType testingObj = dao.findByPK("Input pk");
		dao.delete(testingObj);
		UpdateDataType testingObj2 = dao.findByPK("Input pk");
		Assert.assertEquals(testingObj2, null);
	}

	@Test
	public void testDao() {

		StringBuffer queryString = new StringBuffer();
		queryString
				.append("INSERT INTO ZCFHPF (KEYWORDS, TSEQNO, CANDSC, CHGDESC) VALUES(:a,:b,:c,:d) ");

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("a", new String("a"));
		map.put("b", new Integer(0));
		map.put("c", "c");
		map.put("d", "d");

		int result = dao.executeNativeSQL(queryString, map);

		System.out.println("result=" + result);

	}

}
