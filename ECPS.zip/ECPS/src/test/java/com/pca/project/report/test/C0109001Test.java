package com.pca.project.report.test;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

import com.pca.ecps.util.DateUtils;
import com.pca.my_corefrmwk.report.jasper.Exporter;
import com.pca.my_corefrmwk.report.jasper.FileTypeEnum;
import com.pca.my_corefrmwk.report.jasper.JasperRptLayoutTypeEnum;
import com.pca.my_corefrmwk.report.jasper.PrintMgmtUtil;
import com.pca.project.report.ReportEnum;


public class C0109001Test {

	static final String FILE_PATH = "";//D:\\MPGUploading\\ECPS4J\\src\\main\\resources\\PdfTemplate\\";
	public static void main(String[] args){
		C0109001Test proc = new C0109001Test();
		proc.genPdf();
		/*
		String toDayStr = DateUtils.getToDay();
		System.out.println(toDayStr.substring(0,4));
		System.out.println(toDayStr.substring(4,6));
		System.out.println(toDayStr.substring(6));
		*/
		
	}
	
	//@Test
	public void genPdf() {
		
		//------------init data
		
		FileTypeEnum fileType = FileTypeEnum.PDF;
		PrintMgmtUtil printMgmtUtil = new PrintMgmtUtil();
		String reportLayoutPath = FILE_PATH + ReportEnum.C0109001.toString() ;//+ ".jrxml";
		List<?> dataSource = new ArrayList<String>();
		Map<String, Object> globalParams = new HashMap<String, Object>();
		globalParams.put("CustName", "Arf Test");
		System.out.println("reportLayoutPath=["+reportLayoutPath+"]");
		//----------------------
		try{
			FileOutputStream out = new FileOutputStream(new File("d:\\arf\\aaa.pdf"));
			ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
			Exporter exporter = new Exporter();
			// $F{}
			JRDataSource pJRptDS = new JRBeanCollectionDataSource(dataSource);
			// $P{}
			Map<String, Object> pParams = new HashMap<String, Object>(globalParams);
			// IS_IGNORE_PAGINATION
			if (fileType == FileTypeEnum.EXCEL) {
				pParams.put("IS_IGNORE_PAGINATION", true);
			}
			JasperReport jasperReport = printMgmtUtil.loadReportLayout(
					reportLayoutPath, JasperRptLayoutTypeEnum.JRXML);
	
			JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport,
					pParams, pJRptDS);
	
			if (fileType == FileTypeEnum.EXCEL) {
				exporter.export(jasperPrint, byteArrayOutputStream);
			} else if (fileType == FileTypeEnum.PDF) {
				exporter.exportPDF(jasperPrint, byteArrayOutputStream);
			}
			//return byteArrayOutputStream;
			byteArrayOutputStream.writeTo(out);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
