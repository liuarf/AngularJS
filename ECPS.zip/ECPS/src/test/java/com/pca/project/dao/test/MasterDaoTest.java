package com.pca.project.dao.test;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import com.pca.project.bo.Master;
import com.pca.project.dao.MasterDao;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({ "classpath*:**/test/conf/spring/ApplicationContext.xml" })
// 400請修改transactionManager為transactionManager400
@Transactional("transactionManager")
@TransactionConfiguration(defaultRollback = false)
public class MasterDaoTest {

	@Autowired
	MasterDao dao;

	@Test
	public void testCreate() {
		try{
		Master testingObj = new Master();

		// TODO Input PK
		//testingObj.setId("Input pk");
		testingObj.setCode("LeoTestCode");
		dao.create(testingObj);
		
		Assert.assertNotEquals(testingObj.getId(), null);
		}catch(Exception e){
			e.printStackTrace();
			throw e;
		}
	}

	//@Test
	public void testRead() {

		Master testingObj = dao.findByPK("Input pk");

		Assert.assertEquals(testingObj.getId(), "Input pk");
	}

	//@Test
	public void testUpdate() {
		// TODO update at least a field
		Master testingObj = dao.findByPK("Input pk");
		testingObj.setName("test2");
		dao.update(testingObj);

		Assert.assertEquals(testingObj.getName(), "test2");
	}

	//@Test
	public void testDelete() {
		// TODO Input PK
		Master testingObj = dao.findByPK("Input pk");
		dao.delete(testingObj);
		Master testingObj2 = dao.findByPK("Input pk");
		Assert.assertEquals(testingObj2, null);
	}
}
