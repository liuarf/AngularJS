package com.pca.project.report.test;

import java.util.HashMap;
import java.util.Map;

public class XMLConvertTest {

	
	public static void main(String[] args){
		XMLConvertTest proc = new XMLConvertTest();
		proc.Xml2Map(proc.getXmlMsg());
		
	}
	
	private String getXmlMsg(){
		return "<report><name>C0109001</name><attr>test</attr></report>";
	}
	
	public void Xml2Map(String xmlString){
		Map<String,Object> map = new HashMap<String,Object>();
		
	}
	
}
